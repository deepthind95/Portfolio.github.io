<?php include 'links.php'; ?>   
<section class="section-container py-5">
    
    <div class="container-fluid">
        <h1 class="text-center mb-4">Learning Objectives</h1>

        <div class="owl-carousel owl-theme">
            <!-- Card 1 -->
            <div class="item">
                <div class="card">
                    <img src="img/local-moving.jpg" class="card-img-top img-fluid" alt="Card 1">
                    <div class="card-body">
                        <h5 class="card-title">Library</h5>
                        <a href="#" class="btn btn-primary">Read More</a>
                    </div>
                </div>
            </div>
            <!-- Card 2 -->
            <div class="item">
                <div class="card">
                    <img src="img/sdk.jpg" class="card-img-top img-fluid" alt="Card 2">
                    <div class="card-body">
                        <h5 class="card-title">Laboratories</h5>
                        <a href="#" class="btn btn-primary">Read More</a>
                    </div>
                </div>
            </div>
            <!-- Card 3 -->
            <div class="item">
                <div class="card">
                    <img src="img/asiofjaij.jpg" class="card-img-top img-fluid" alt="Card 3">
                    <div class="card-body">
                        <h5 class="card-title">Sports</h5>
                        <a href="#" class="btn btn-primary">Read More</a>
                    </div>
                </div>
            </div>
            <!-- Card 4 -->
            <div class="item">
                <div class="card">
                    <img src="img/iedviom.jpg" class="card-img-top img-fluid" alt="Card 4">
                    <div class="card-body">
                        <h5 class="card-title">Computer Lab</h5>
                        <a href="#" class="btn btn-primary">Read More</a>
                    </div>
                </div>
            </div>
            <!-- Card 5 -->
            <div class="item">
                <div class="card">
                    <img src="img/fgjiodo.jpg" class="card-img-top img-fluid" alt="Card 5">
                    <div class="card-body">
                        <h5 class="card-title">Co-Curricular Activities</h5>
                        <a href="#" class="btn btn-primary">Read More</a>
                    </div>
                </div>
            </div>
            <!-- Card 6 -->
            <div class="item">
                <div class="card">
                    <img src="img/eksicmsom.jpg" class="card-img-top img-fluid" alt="Card 6">
                    <div class="card-body">
                        <h5 class="card-title">Transport</h5>
                        <a href="#" class="btn btn-primary">Read More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script>
$('.owl-carousel').owlCarousel({
    loop: true,
   items:3,
   margin:24,
    nav: true,
    dots: false,
    navText: [
                "<i class='fas fa-arrow-left'></i>",
                "<i class='fas fa-arrow-right'></i>"
            ],
   
});

</script>
