<?php
include 'top.php';
include 'links.php';
include 'navbar.php';
?>
<div class="container-fluid mt-1 image1">
    <div class="position-relative">
        <div class="carousel-overlay position-absolute  start-0 w-100 h-100 bg-dark opacity-50"></div>
        <img src="img/slider-01.jpg" class="image" alt="">
        <div class="carousel-caption text-end position-absolute top-50 start-50 translate-middle text-light">

            <h2 class="fw-bold">Chairman Messege</h2>

        </div>
    </div>
    <section class="py-5 section-container">
        <div class="container-fluid">



            <div class="row">
                <div class="col-md-4">
                    <img src="img/hnji.jpg" class="img-fluid  img-thumbnail w-100 img2" alt="School Building">
                </div>
                <div class="col-md-8">

                    <h1 class="text-uppercase">From Chairman's Desk</h1>
                    <div class="border border-dark  w-25 my-1"></div>
                    <p class=" text-break text-justify  bg-light text">Jogindra Convent School, Jogindergarh (Ferozepur)
                        established in 2009 under the aegis of the Sardar Joginder Singh Charitable Trust, is committed
                        to prepare global citizens equipped with the life skills required to meet the constantly
                        changing challenges and needs of the world around them. As part of a society that stands for
                        educational leadership, scholarly achievement and a progressive approach, we combine the tenets
                        of a traditional value based system with global trends and a world class infrastructure.
                        Education, for us, is not a destination but a journey of discovery, of exploration, of
                        introspection, of interrogation,...</p>
                    <h4 class="  p-2 w-50 my-2">Hardeep Singh</h4>
                    <h5 class="bg-light text-dark p-2 w-50 my-2">M.A, LLB.</h5>



                </div>
            </div>
        </div>
    </section>
    <?php include 'footer.php'; ?>