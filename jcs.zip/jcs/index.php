<?php include 'top.php';
include 'links.php';
include 'navbar.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jogindra Convent School</title>
</head>

<body>
    <?php include 'slider1.php'; ?>

    <!-- About Us Section -->
    <section class="py-5 section-container">
        <div class="container-fluid">
            <div class="row">
                <!-- 30% Column -->
                <div class="col-md-6">
                    <h6 class="fw-bold">Welcome to</h6>
                    <h1 class="text-uppercase">Jogindra Convent School</h1>
                    <div class="border border-dark  w-25"></div>
                    <p class=" text text-justify bg-light">With early education gaining new dimensions the dire need is
                        not only to succeed but to lead in this intensely competitive, technology driven and fast
                        evolving global society, JCS completes the design of this type of educational programme,
                        stretching from Kindergarten to Class Xl with all streams. School education is the foundation
                        for a student's life. Unless and until the quality of education at the school level is improved,
                        it is futile to expect quality in higher education. Set in a calm, safe, pristine, pollution
                        free, eco-friendly environment, JCS has truly been a milestone for this rural area as it
                        provides global learning experience to its students and nourishes them to be responsible
                        citizens....</p>
                    <a class="btn btn-md btn-primary  py-2" href="about.php">Read More</a>
                </div>

                <!-- 70% Column -->
                <div class="col-md-6">
                    <img src="img/about-service.jpg" class="img-fluid rounded img-thumbnail img1" alt="School Building">
                </div>
            </div>
    </section>
    <section class="py-5 section-container">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-4">
                    <img src="img/hnji.jpg" class="img-fluid  img-thumbnail w-100 img2" alt="School Building">
                </div>
                <div class="col-md-8">

                    <h1 class="text-uppercase">From Chairman's Desk</h1>
                    <div class="border border-dark  w-25 my-1"></div>
                    <p class=" text-break text-justify  bg-light text">Jogindra Convent School, Jogindergarh (Ferozepur)
                        established in 2009 under the aegis of the Sardar Joginder Singh Charitable Trust, is committed
                        to prepare global citizens equipped with the life skills required to meet the constantly
                        changing challenges and needs of the world around them. As part of a society that stands for
                        educational leadership, scholarly achievement and a progressive approach, we combine the tenets
                        of a traditional value based system with global trends and a world class infrastructure.
                        Education, for us, is not a destination but a journey of discovery, of exploration, of
                        introspection, of interrogation,...</p>
                    <h4 class="  p-2 w-50 my-2">Hardeep Singh</h4>
                    <h5 class="bg-light text-dark p-2 w-50 my-2">M.A, LLB.</h5>
                    <a class="btn btn-md btn-primary  py-2" href="chairman_message.php">Read More</a>


                </div>
            </div>
        </div>
    </section>
    <!-- End of Chairman Desk -->


    <section class="py-5 section-container">
        <div class="container">
            <h1 class="text-center mb-4">Why Jogindra Convent School</h1>
            <div class="row">
                <!-- Column 1 -->
                <div class="col-md-4 ">
                    <div class="card height shadow-lg">
                        <img src="img/eyee.png" class="w-25 mx-auto d-block img-fluid zoom-effect" alt="Card 1">
                        <div class="card-body">
                            <h5 class="card-title text-center">Vision</h5>
                            <p class="card-text">We have the zeal, vision, conviction and belief to bring to one door
                                step, what is prevailing and is progressing towards path breaking land marks of
                                education.</p>
                        </div>
                    </div>
                </div>

                <!-- Column 2 -->
                <div class="col-md-4">
                    <div class="card height pt-2 pb-2 shadow-lg">
                        <img src="img/bbb.png" class="w-25 mx-auto d-block img-fluid zoom-effect" alt="Card 2">
                        <div class="card-body">
                            <h5 class="card-title text-center">BELIEFS & VALUES</h5>
                            <p class="card-text">That all students should have a safe environment conducive to learning
                                that fosters positive self-esteem, self-discipline, and responsibility. that all
                                students have the ability to learn and that learning is a life-long process..</p>
                        </div>
                    </div>
                </div>

                <!-- Column 3 -->
                <div class="col-md-4">
                    <div class="card height shadow-lg">
                        <img src="img/missio.png" class="w-25 img-fluid mx-auto d-block zoom-effect" alt="Card 3">
                        <div class="card-body">
                            <h5 class="card-title text-center">Mission</h5>
                            <p class="card-text">To Raise future leaders with a sense of understanding, Tolerance and
                                empathy and to educate them to respect the cultural, linguistic and communal diversity
                                of humanity.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section-container">
        <div class="container">

            <div class="row">
                <!-- Column 1 -->
                <div class="col-md-4">
                    <div class="card shadow-lg h-100">
                        <img src="img/pre-nur1.jpg" class="img-fluid img-thumbnail mx-auto d-block w-100" alt="Card 1">

                    </div>
                </div>
                <!-- Column 2 -->
                <div class="col-md-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title text-center">Latest News</h5>


                            <div style="overflow: hidden; height: 250px; position: relative;">
                                <marquee behavior="scroll" direction="up" scrollamount="5" onmouseover="this.stop();"
                                    onmouseout="this.start();" class="bg-white text-dark px-3 pt-3 rounded">
                                    <div class="list-group">
                                        <?php
                                        include 'includes/db.php';
                                        $news = $conn->query("SELECT * FROM news ORDER BY id DESC LIMIT 10");

                                        while ($row = $news->fetch_assoc()) {
                                            $title = htmlspecialchars($row['title']);
                                            $description = substr(strip_tags($row['description']), 0, 80);
                                            $link = !empty($row['link']) ? htmlspecialchars($row['link']) : "view_news.php?id=" . $row['id'];
                                            $target = (!empty($row['link']) && str_starts_with($row['link'], 'http')) ? ' target="_blank"' : '';

                                            $imageFile = htmlspecialchars($row['image']);
                                            $pdfFile = htmlspecialchars($row['file']);

                                            $imagePath = (!empty($imageFile) && !str_ends_with(strtolower($imageFile), '.pdf'))
                                                ? 'admin/' . $imageFile
                                                : '';
                                            $pdfPath = (!empty($pdfFile) && str_ends_with(strtolower($pdfFile), '.pdf'))
                                                ? 'admin/' . $pdfFile
                                                : '';

                                            // Get file extension for rendering condition
                                            $fileExt = strtolower(pathinfo($imagePath ?: $pdfPath, PATHINFO_EXTENSION));
                                            ?>
                                            <div class="d-flex mb-4 align-items-start gap-3">
                                                <?php if (!empty($imagePath) && in_array($fileExt, ['jpg', 'jpeg', 'png', 'gif'])): ?>
                                                    <img src="<?= $imagePath ?>" alt="<?= $title ?>" class="rounded border"
                                                        style="width: 80px; height: 80px; object-fit: cover;">
                                                <?php elseif (!empty($pdfPath) && $fileExt === 'pdf'): ?>
                                                    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANkAAADpCAMAAACeGmLpAAABF1BMVEVXseP////xWU7S1NPY2tleteTW2Nft7e3xSDrq7OtXsuH//fxUsub9/v9csN/N5fRIrOLx+PnvWU/5u7CEm8P5Uj3wT0P+9vPo8/vzWE3o5+jd3972o530jYP51tLQ4/X2mI7yYlNNquLKNS/LQT30bmH4yMXK5vT//P+uytvf2tfX2d3yWFLvkIX0gXn0//+j0+7W6PGtyOCx2uxwu+VHrezY29HV2eKuy9ZGsOGwyd5ir9WNmbT/Rzf0U0HvPi3vtbP5xr71qqb42czxcGfrVz399+j4UVDqaFb26uH1SETufnj6mIvoWkz84+D0wrLxlZi0Ul60V1XTMipPtt1XrPLCT0i9VFHPKxnPOTe0X11+wt+UzeFkQ4dLAAAHzklEQVR4nO2dgVvaRhTAk4wiTS4RQxuaighxKGoktorV2aVVsVZb3Fzt2m77//+OvUtCAMHUlVzuyN7v+/yUOwL3413evQuUShKCIAiCIAiCIAiCiIJD1ATgDhMN0kTjA44jJD42K26zeULVIJk8Twxxyt1yAoRMaSJTWr93HMlWjJT3d188y4TNMslwNjrl3SU5I55vlp3s1JwNTcvKbHnrZRnySEZie5rmZWa2vbWZTdDg5duX5cxCJi8XCwcQtQyCppLyXmZaoVlx67BLFzbmbiSz7BGZFWBClonB3Et6pGdstn2wfbBJgudmy6PsTrLQjBJEjfWE5GIGE5IwX7K5mBWySP58zLYKhcOuITGdkHzMaNQOHbY7Gl5mhVegxjT5czMrFAubRxLD5M/PrACF1pFkMFPjabZ98AvD/RpXswLL5M/TjKodllnlfq5mBVr5s9qKcjajyZ9R5c/brFCENGIQBhkyY7MJMZohN8sskj/3mBW2Xm0xuVjH34ymSKghcxgzysGmk3oWEcNsm0HyF8Os8Opg5nONEEM9NoYca1W2PMzsYHt5kyZ/6ccnpSp1X//6dIhfYsqbt7I+MiumZf3BhKRXtI5nSv5Hry1lgOvabLEq+qjZ4/tiFkzIQ5hQM5gZ5LVvDlBsV1FMhoBZe2Q2LiWYFbYKM1b+6pOnSmZYFXnsUm3CdKRA5T8LPM30pKAF59osyZ+nmbyQqAbJ35kh+XM1k/XlYnHCLmooFmHJnteY0TTyePl+trdezq9ZIp62lPJstK0hsA5NbbdG2ic7gRTMZG3JSdHMtM1OPWL9pLLT8kEhsDCV60FH/eR0pelb7ojYTn2Us7OmffeR/7uZnG7MbHcnelydUq33rpR+0NGKBkZ/edDRKQ1Hb9V0b2TcelU8M1exVmAehGVQW5M9z6tZF1Ss78rxZyqCakKvN+NJZ9W89piZe/eBuZvZpr0CI/CqS1Xw8PS2puuNc2hW7KYOYYT9gFbVIEBwQ9Y6lhnHrK1577SI9mXrXEgzeNF7zWaz9+H0HRi0310EXU36ZLVms9XqdWpn0KHJWs+OzUD1fStG0JiBWatP6/O+ewkD9ho2TSKBWcOHAELhXupc6m04DX07NtP1q8F+oX/RF+48i8zk967iwgz0P3i6pp9Y9iBmHyF5wsbAtK3+tafJ+ttwPoYx8wc+dt82RTVrhTdd6xJuXJfMgVkD7hDdsxfMVNekEqGZNTkHxTUrXVMzy7QnzJTSb7re9hpB3/yZKQkx67foJrke6MyTWTD+i34Lsr68bimTMTNtuwqp5tqOZ6N3NXgUN9ihi2nWM03Xtc9LFQ9yYy1Yke+aKVYdGsJqI8iN8pUfl5WKsLmxaVm+7/crMMcgS9hTzBTFX4+jG8RM+73WqDUa8FPrCWvmwQhrp/Uq1Eyafuor084z5fxEpiufMjDzoGaJaNzdCwhjFqHrHqxm0es/YWaFMYtzo6wPqivvo+Bm9PqgXrEUd5qZq5ToeaY1lchMo7uD6MDGhJhYZnL7utLyB4O8Y2baPl3rqsrgPIO1rTagZ/YFNaPnWWOl04Ms595jZptuFWJ0bbnxSl26d8stjpn83rIu7PHx3Y2Zv0JnYMU3lflaqaHGUJQkM+XqDBK917GVuasbobgYK9gjMyW4MAJ774auee3Lq5Faf17M7hKahZezIDGu0NpK3wkvGOTBDAIJG0+reQJrgq6flcy8mNV6wEqtDgFrwyZgMF1zYBYOji7Jmu7V461zDswotDKhl7dqpTh55sSMhqx6fTqqMQdmUDR11oFpZusRJ5XTTovWGcNVwV6hHZOFh0hm0ZsP0waZ8IZFeFCSmAhmjEAzNEMzNJsfs+HnovJmxtqHk5n65GmzGX7ei/5m+zHAN1maOcc3n9a+rUX8HL3pzor/qDWDGblVu+ofa59GzATjh2Pm3KrS5z/X8memqsRR1aM4avkxoxD1s3qTu5gFZjAhnS9fc2imOvDTvfmUP7PQ7jhQy50ZuSVd8gXSSO7MguTf/ZLDmAVfFyaRm6+5Mwv1Pt/efMv0X/w8hBTMIPkbzl9apl/q8gBSMKPJ35HyGLOAbP/92UNAMzQTBzRDM3FAMzQTBzQT0yypCmdutvATSxbQDM2EMUv4dlY0E9SM62xM/u6EGeEZM26gGZqJA5qhmTigGZpNPsFzliS8nnNeN+a3IkYzNBPHLL9XC3iaaQss4Zn1uZFjs0e5NctvzNAMzYQBzdBsgh+trooJXcO+pIo4HTERa300mz8zUc8zNONoVmQIVzNuoBmaiQOaoZk4oBmaTZDfa8T5va6f44qYqVl+Y5Zfs/zORp5m2mOW4DuDaIZmXEEzNBMHNEMzcUAzNBMHNEMzcUAzNBMHNPvfmhnE420yjtZe+vH/eXucZ7xdxtG1F+U0tFQi7fF2uYO2m4qZRCRjSRbmVIOBaM9S8aKUd8X5Bkf6PeF/SynlxkBNlKDBQP5xjoy0zKSjfWGyyIt9h6QnBpT39zYWgY2N4NeQ1dXV4V+rI93w12pMdGvssLBjcbx9pG+ycXFxb7+cVsYfcQtwHKecwLDbGbun853jHgaMoUuk1NUIMQxDBYwxhi1qxPitMcYPi1qmPuTURkIk1UjfzIAH5gukRFUi6SVGBEEQBEEQBEEQBEEQRGT+BUl95SLfz/XzAAAAAElFTkSuQmCC"
                                                        alt="PDF" class="rounded border"
                                                        style="width: 80px; height: 80px; object-fit: contain; background-color: #f5f5f5;">
                                                <?php else: ?>
                                                    <img src="assets/images/default-news.jpg" alt="No Image"
                                                        class="rounded border"
                                                        style="width: 80px; height: 80px; object-fit: cover;">
                                                <?php endif; ?>

                                                <div class="flex-grow-1">
                                                    <h6 class="mb-1 text-primary"><?= $title ?></h6>
                                                    <p class="mb-2 small text-muted"><?= $description ?>...</p>

                                                    <?php if (!empty($pdfPath) && $fileExt === 'pdf'): ?>
                                                        <a href="<?= $pdfPath ?>" target="_blank"
                                                            class="btn btn-sm btn-outline-danger">Download PDF</a>
                                                    <?php else: ?>
                                                        <a href="<?= $link ?>" <?= $target ?>
                                                            class="btn btn-sm btn-outline-primary">View Post</a>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <hr class="my-2">
                                        <?php } ?>
                                    </div>
                                </marquee>
                            </div>


                        </div>
                        <a href="index.php" class="btn btn-info w-100 text-white">Read More</a>

                    </div>
                </div>
                <!-- Column 3 -->
                <div class="col-md-4">
                    <div class="card h-100 shadow-lg">
                        <img src="img/sch-4.jpg" class="card-img-top img-fluid img-thumbnail h-100" alt="Card 3">



                    </div>
                </div>

            </div>
    </section>
    <?php include 'slides3.php'; ?>

    <section id="counter_area_main" class="py-5 bg-light">
        <div class="container-fluid">
            <div class="row text-center">
                <!-- Counter 1 -->
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="counter_area">
                        <div class="counters_icon mb-3">
                            <i class="fa fa-graduation-cap fa-3x text-primary" aria-hidden="true"></i>
                        </div>
                        <div class="counter_count">
                            <h2 class="counter-value text-light counter">25</h2>
                            <h5 class="text-light">Years of Experience</h5>
                        </div>
                    </div>
                </div>
                <!-- Counter 2 -->
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="counter_area">
                        <div class="counters_icon mb-3">
                            <i class="fa fa-users fa-3x text-success" aria-hidden="true"></i>
                        </div>
                        <div class="counter_count">
                            <h2 class="counter-value text-light counter">900</h2>
                            <h5 class="text-light">Students</h5>
                        </div>
                    </div>
                </div>
                <!-- Counter 3 -->
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="counter_area">
                        <div class="counters_icon mb-3">
                            <i class="fas fa-chalkboard-teacher fa-3x text-warning"></i>
                        </div>
                        <div class="counter_count">
                            <h2 class="counter-value text-light counter">60</h2>
                            <h5 class="text-light">Teachers</h5>
                        </div>
                    </div>
                </div>
                <!-- Counter 4 -->
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="counter_area">
                        <div class="counters_icon mb-3">
                            <i class="fa fa-bus fa-3x text-danger" aria-hidden="true"></i>
                        </div>
                        <div class="counter_count">
                            <h2 class="counter-value text-light counter">19</h2>
                            <h5 class="text-light">School Buses</h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Testimonial Section -->
    <?php include 'slider2.php'; ?>




    <section class="py-5 section-container">
        <div class="container">
            <div class="row">
                <!-- Image Section -->
                <div class="col-md-6">
                    <img src="img/noooo.jpg" class="img-fluid rounded img-thumbnail" alt="Admission Image">
                </div>
                <!-- Admission Enquiry Form -->
                <div class="col-md-6">
                    <h2 class="text-center mb-4">Admission Enquiry Form</h2>
                    <form>
                        <div class="mb-3">
                            <label for="studentName" class="form-label">Student Name</label>
                            <input type="text" class="form-control" id="studentName" placeholder="Enter student's name">
                        </div>


                        <div class="mb-3">
                            <label for="phone" class="form-label">Phone</label>
                            <input type="tel" class="form-control" id="phone" placeholder="Enter your phone number">
                        </div>

                        <div class="mb-3">
                            <label for="message" class="form-label">Message</label>
                            <textarea class="form-control" id="message" rows="4"
                                placeholder="Enter your message"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <script>
        $('.counter').counterUp({
            delay: 10,
            time: 1000
        });
    </script>
</body>

</html>



<?php include 'footer.php'; ?>