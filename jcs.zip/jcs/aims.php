<?php include 'top.php';
include 'links.php';
include 'includes/db.php';
include 'navbar.php';
$query = "SELECT * FROM students WHERE designation = 'STUDENT OF THE YEAR' ORDER BY id ASC LIMIT 10";
$result = mysqli_query($conn, $query);
$dir="uploads/"

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  
  <link rel="stylesheet" href="css/style.css">
  <title>Jogindra Convent School</title>



</head>
<div class="container-fluid mt-1 image1">
  <div class="position-relative">
    <div class="carousel-overlay position-absolute  start-0 w-100 h-100 bg-dark opacity-50"></div>
    <img src="img/slider-01.jpg" class="image" alt="">
    <div class="carousel-caption text-end position-absolute top-50 start-50 translate-middle text-light">

      <h2 class="fw-bold text-uppercase">Aim and Objectives</h2>




    </div>
  </div>
  <div class="my-3"></div>
  <section class="py-5 section-container">
        <div class="container">



            <div class="row">
                <div class="col-md-4">
                    <img src="img/rightimg.jpg" class="img-fluid img-thumbnail w-100 shadow-lg" alt="School Building">
                </div>
                <div class="col-md-8">
                <ul class="daljit text-break text-justify bg-light text">
                <li><i class="fa fa-arrow-right" aria-hidden="true"></i> To impart value based quality education. </li>
                <li><i class="fa fa-arrow-right" aria-hidden="true"></i> To achieve and sustain academic standards, qualitatively as well as quantitatively. </li>
                <li><i class="fa fa-arrow-right" aria-hidden="true"></i> To enable the students to learn self discipline. To provide facilities for physical and <br>spiritual development. </li>
                <li><i class="fa fa-arrow-right" aria-hidden="true"></i> To raise the moral of the students in sense of politeness, respect and manners. </li>
                <li><i class="fa fa-arrow-right" aria-hidden="true"></i> To instill among them a national feeling and love for their ancient cultural and national <br>heritage. </li>
                <li><i class="fa fa-arrow-right" aria-hidden="true"></i> To sharpen their aesthetic sense and humor for appreciation of art and higher value of <br>life. </li>
                <li><i class="fa fa-arrow-right" aria-hidden="true"></i> To have a wide vision and clear thinking to face the challenge of life. </li>
                <li><i class="fa fa-arrow-right" aria-hidden="true"></i> To make them respected and responsible citizens of future India. </li>
            </ul> 


                </div>
            </div>
        </div>
    </section>
    <?php include 'footer.php'; ?>