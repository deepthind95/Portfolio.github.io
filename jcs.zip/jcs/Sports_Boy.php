<?php
include 'top.php';
include 'links.php';
include 'includes/db.php';
include 'navbar.php';
$query = "SELECT * FROM students WHERE designation = 'Sports Boy Of the Year' ORDER BY id ASC LIMIT 10";
$result = mysqli_query($conn, $query);

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  
  <link rel="stylesheet" href="css/style.css">
  <title>Jogindra Convent School</title>



</head>
<div class="container-fluid mt-1 image1">
  <div class="position-relative">
    <div class="carousel-overlay position-absolute  start-0 w-100 h-100 bg-dark opacity-50"></div>
    <img src="img/slider-01.jpg" class="image" alt="">
    <div class="carousel-caption text-end position-absolute top-50 start-50 translate-middle text-light">

      <h2 class="fw-bold text-uppercase">Sports Boy of the Year</h2>




    </div>
  </div>
  <div class="my-3"></div>
 


<!-- Table to Display Students -->
<div class="container ">


    <table id="studentTable" class="table text-center table-bordered table-danger my-3">
      <thead>
      <tr class="table-dark">
      <th>#</th>
      <th>Photo</th>
      <th>Student Name</th>
      <th>Designation</th>
      <th>Session</th>
      </tr>
      </thead>
      <tbody>
      <?php
      $id = 0;
      while ($row = mysqli_fetch_assoc($result)) {
      $id++;
      ?>
      <tr>
      <td><?= $id; ?></td>
      <td><img src="<?php echo htmlspecialchars($row['student_photo']); ?>" class="img-fluid img-thumbnail" width="50" alt="Student Photo"></td>
      <td><?php echo htmlspecialchars($row['student_name']); ?></td>
      <td><?php echo htmlspecialchars($row['designation']); ?></td>
      <td><?php echo htmlspecialchars($row['session']); ?></td>
    
    </tr>
    <?php } ?>
  </tbody>
  
    </table>

  


<?php include 'footer.php'; ?>