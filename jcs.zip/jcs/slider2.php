<section class="py-5 bg-light section-container">
    <div class="container">
        <h2 class="text-center mb-4">Testimonials</h2>
        <div class="owl-carousel owl-theme">
            <!-- Testimonial 1 -->
            <div class="item">
                <div class="card">
                    <div class="card-body">
                        <h2 class="card-text text-center">Rajbir Kaur</h2>
                        <div class="stars text-center">
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                        </div>
                        <i class="fas fa-quote-left opacity-25 fs-1"></i>
                        <p class="card-text text-justify text">The most important day of the person's education is
                            the first day of school not graduation day. I have great memories of my childhood in
                            school. Through this school, I come to know what exact the life is. I learnt many
                            skills,
                            got Knowledge from my lovable staff. This is the school which gives platform to the
                            students who actually deserves and polish the students. I am one of them, they boost up
                            my confidence and gave wings to my dreams. I shall always be thankful to them who helps
                            me to stand in my life.</p>
                    </div>
                </div>
            </div>
            <!-- Testimonial 2 -->
            <div class="item">
                <div class="card">
                    <div class="card-body">
                        <h3 class="text-center">Tania Arora</h3>
                        <div class="slider_two_rating text-center stars">
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                        </div>
                        <div class="slider_two_text">
                            <i class="fas fa-quote-left opacity-25 fs-1"></i>
                            <p class="text">This school has been such a true blessing to us. From the infrastructure
                                to the teachers, it’s hands down the best school around. Thank you to JCS.</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Testimonial 3 -->
            <div class="item">
                <div class="card">
                    <div class="card-body">
                        <h3 class="text-center">Navdeep Dhunna</h3>
                        <div class="slider_two_rating text-center stars">
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                        </div>
                        <div class="slider_two_text">
                            <i class="fas fa-quote-left fs-1 opacity-25"></i>
                            <p>I have amazing experience with jcs . I cannot forget the days i had spent at jcs with
                                teachers and friends. Quality of education at jcs is wonderful. I recommend all
                                students to take admission at jcs for better future.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="card">
                    <div class="card-body">
                        <h3 class="text-center">Veer K</h3>
                        <div class="slider_two_rating text-center stars">
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                        </div>
                        <div class="slider_two_text">
                            <i class="fas fa-quote-left opacity-25 fs-1"></i>
                            <p class="text">Studied here till 10th...The staff, infrastructure, facilities, life
                                experience, environment are unmatched.....here teachers not only aim to educate a
                                child rather it is to mould him in the best possible way to take life head on ...you
                                feel loved, blessed and protected here...once you become JCSian you are always part
                                of it</p>
                        </div>
                    </div>
                </div>


            </div>
            <div class="item">
                <div class="card">
                    <div class="card-body">
                        <h3 class="text-center">Sukhman Chandi</h3>
                        <div class="slider_two_rating text-center">
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                        </div>
                        <div class="slider_two_text">
                            <i class="fas fa-quote-left opacity-25 fs-1"></i>
                            <p class="text">Awesome school with extraordinary staff and helps the young ones to
                                explore their talent in front of the world!</p>
                        </div>
                    </div>
                </div>


            </div>

            <div class="item">
                <div class="card">
                    <div class="card-body">
                        <h3 class="text-center">Neha Chatrath</h3>
                        <div class="slider_two_rating text-center">
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                            <i class="fas fa-star stars"></i>
                        </div>
                        <div class="slider_two_text">
                            <i class="fas fa-quote-left opacity-25 fs-1"></i>
                            <p class="text">It is an education place where I am working to cherish my knowledge and
                                enhance my skills to grow further in a healthy environment.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="text-center my-3">
        <a class="btn btn-primary btn-sm" href="https://maps.app.goo.gl/vdakFmwzkthUSZ5q6" target="_blank">Click
            Here to view
            More</a>
    </div>
</section>
<script>
    $(document).ready(function () {
        $(".owl-carousel").owlCarousel({
            nav: true,
            loop: true,
            autoplay: true,
            items: 1,
            dots: false,
            navText: [
                "<i class='fas fa-arrow-left'></i>",
                "<i class='fas fa-arrow-right'></i>"
            ],

        });

    });
</script>