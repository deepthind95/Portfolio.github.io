<?php include 'links.php'; ?>

<div id="schoolCarousel" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">

        <!-- Slide 1 -->
        <div class="carousel-item active position-relative">
            <img src="img/slider-01.jpg" class="d-block w-100" alt="Welcome to Jogindra Convent School">
            <div class="carousel-overlay position-absolute top-0 start-0 w-100 h-100 bg-dark" style="opacity: 0.5;"></div>
            <div class="carousel-caption container-fluid text-start top-50 text-light">
                <h6 class="text-uppercase">Welcome To</h6>
                <h4 class="fw-bold">Jogindra Convent School</h4>
                <p>We focus on all-round development of students</p>
                <a href="#contact" class="btn btn-primary">Contact Us</a>
            </div>
        </div>

        <!-- Slide 2 -->
        <div class="carousel-item position-relative">
            <img src="img/slider-02.jpg" class="d-block w-100" alt="Leadership and Growth">
            <div class="carousel-overlay position-absolute top-0 start-0 w-100 h-100 bg-dark" style="opacity: 0.5;"></div>
            <div class="carousel-caption container text-start text-light">
                <h4 class="fw-bold">ILLUMINATING PATHS OF<br>TOMORROW’S LEADERS</h4>
                <p>Every kid makes parents happy</p>
                <a href="#contact" class="btn btn-primary">Contact Us</a>
            </div>
        </div>

        <!-- Slide 3 -->
        <div class="carousel-item position-relative">
            <img src="img/slider-03.jpg" class="d-block w-100" alt="Learning with Love">
            <div class="carousel-overlay position-absolute top-0 start-0 w-100 h-100 bg-dark" style="opacity: 0.5;"></div>
            <div class="carousel-caption container text-start text-light">
                <h4 class="fw-bold">Learning Life with Love</h4>
                <p>If it's a matter of Learning, We are there</p>
                <a href="#contact" class="btn btn-primary">Contact Us</a>
            </div>
        </div>

        <!-- Slide 4 -->
        <div class="carousel-item position-relative">
            <img src="img/slider-04.jpg" class="d-block w-100" alt="S. Joginder Singh Dhaliwal">
            <div class="carousel-overlay position-absolute top-0 start-0 w-100 h-100 bg-dark" style="opacity: 0.5;"></div>
            <div class="carousel-caption container text-start text-light">
                <h4 class="fw-bold">S. Joginder Singh Dhaliwal</h4>
                <p>The Inspiration</p>
                <a href="#contact" class="btn btn-primary">Contact Us</a>
            </div>
        </div>
    </div>

    <!-- Carousel Controls -->
    <button class="carousel-control-prev" type="button" data-bs-target="#schoolCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon bg-dark rounded-circle p-2" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#schoolCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon bg-dark rounded-circle p-2" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>
