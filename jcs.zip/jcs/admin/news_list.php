<?php
session_start();
include 'top.php';  
include('includes/db.php');
include 'links.php';
include 'sidebar.php';

$query = "SELECT * FROM news ORDER BY id DESC";
$result = $conn->query($query);
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-11">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">News Management</h5>
                    <a href="add-news.php" class="btn btn-light btn-sm fw-semibold">+ Add News</a>
                </div>
                <div class="card-body">
                    <?php if ($result->num_rows > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover align-middle text-center">
                                <thead class="table-dark">
                                    <tr>
                                        <th scope="col">Title</th>
                                        <th scope="col">Description</th>
                                        <th scope="col">Link</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">PDF</th>
                                        <th scope="col">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($row = $result->fetch_assoc()): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($row['title']) ?></td>
                                            <td><?= nl2br(htmlspecialchars($row['description'])) ?></td>
                                            <td>
                                                <?php if (!empty($row['link'])): ?>
                                                    <a href="<?= htmlspecialchars($row['link']) ?>" target="_blank">
                                                        <?= htmlspecialchars($row['link']) ?>
                                                    </a>
                                                <?php else: ?>
                                                    <span class="text-muted">No Link</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php
                                                $imagePath = $row['image'];
                                                $imageFullPath = !empty($imagePath) ? __DIR__ . '/' . $imagePath : '';
                                                if (!empty($imagePath) && file_exists($imageFullPath)) {
                                                    echo '<img src="' . htmlspecialchars($imagePath) . '" alt="News Image" class="img-thumbnail w-25 img-fluid  ">';
                                                } else {
                                                    echo '<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAtFBMVEXi5ef////xVkLK0diwt73xUTzh6+3sin7pdmzP1dzI197xUz7m6er+8O7j5ujzdWfwTDXvaFbwQif4t7H0hXnR1djwRy72lIfL0tn/+vm1vMH96ef2m5D84uD6x8LyYk/829fy9PT0fnD2j4Lzbl73opj5wbv4r6f+7er70Mz4ta/zZVLyXEi/xMnZ3d/otLDk0tLrlo7j29zmwL33qKD71dHgmpTVvsDNxsvih37qdmvcmpaxpVB3AAAHNElEQVR4nO3da1ujOBgG4IJmHAfbRlt7GGyl52rR2UOdndn9//9rqRIgkIQELLzJlefab5aa2zyFcNhOx1HPYnHTOX96970KYyumo+5rgvcuvLxpRdiQ7134/TOIisJFryngSXh5qV6xmsKmGpoIP6GoasLmZpAI6xdVSdjgDBJh/aKqbN/ghzAjrFtUFWGjU5gKaxZVRdgoMBXWLKrCxovWhLWKqiBstqSUsE5R9RDWKarClo3uSfPC6kXVZQ6rF1UbYeWiaiSsWFSdhNWKqpOwWlH1ElYpqmbCCkXVTFihqNoJlYuqn1C1qPoJVYuqo1CtqFoKlYqqpVCpqJoKFYqqq1C+qLoK5Yuqr1C2qBoLJYuqsVCyqFoLpYqqt1CmqHoLZYqqu7C8qNoLS4uqvbC0qAYIS4pqglBcVBOE4qKaIRQV1RChoKiAha/fFYj8osIVdnovKkJuUSELVWrKLypgYaenJOQVFbRQbRI5RYUs7HTUPonsooIW9lSJrKKCFkZEpSPGJauosIXRQbF2UYELO73eveI05kXQhaem3r8oIXOzCF94Mr5GuZDMy7V+wlNXe73O9cXFZFL+34WWwndlZyI3idoKo/2qHFFfYee9qEYLJYuqs1CuqFoLpYqqt1CmqJoLJYqqu7C8qNoLS4uqv7CsqAYIS4pqglBcVCOEwqKaIRQV1RChoKimCPlFNUbILao5Ql5RDRJyimqSkF1Uo4TMopolZBXVMCGjqKYJi0U1TlgoqnnCfFENFOaKaqKQLqqRQqqoZgqzRTVUmCmqqcK0qMYKk6KaKyRFNVgYF9Vk4UdRjRa+F9Vs4amohgujWTRdGBmNF2r4XJtirNAK4ae68AuQlH27YalwOhuMmbmCkR9/dMTGMqG/QRhBDg7//EtILBHu+8iFHjwUEkuEj/CBEfFKRBQL56O2Ry8V7+/KwqEOU+i66OpLRWG377U9eKl4t1ZohdBjhVYIP1ZohfBjhVYIP1ZohfBjhTWECI/oYIwYmxQukHnc9/XYV9TE4zijcLj1qQTb3Wrt5S59oHA5pLPsH1zMukDiueshM+KBnE2IN1OnmNlgSV2/Qsu3/Mum+2B+XKKiMdz5jHeMst/iNoSIPRqnu8sM3rudcV4VrEc5I95w3jHKRkA8lxCtuMMJ1snY8Y4/6rclPezRnv9aXzCSswnH/PHMHsmWeMB/ldMdU7/gTvBS/8AfSxtCZy4ldKbH7CyKhLM2WioSOjskI3Sc58zIRcKl4OL0uYXTp+dBnG26V/HXHi18C5JQO8xxSuQLZ6IdzfmF4+hA/xF0O+6SjR8QLXRvSQ7r4S49gPjpXokI3wrHw3Urx8NE+JA5NmBE9oezES2889IgfJcan8K8cF5Y2bSzpmEJTwd4Mou5Obyjt8arZLZXZPtEKPS0LXS9bbz1x81VnjD6UySTSNZAmgiTSRyLhS5+IL+HHDw1EXqHeFe5w2Kh9/gW/4gcFDURujg+ZGxLhC56iPc2gV5C6Tl0vTB+5T4+GKRCLxtoQunPYbTSnsfvEO9NE+HhMZsQlyCbFhLSslSIHuh3IMIpfV7tz/Mn1a0K8YocysXHw/eRreOfDTAlLGQPZ03j4j45kBfWNKyRSQqdrQjYwLr0jqxLR/iYrFTitfLnCH3hJJ797CnYkgTptsEhd25Rp6XOXjiSds4PN/nzQ9aehrzDsbSlYXHrloVP5FUiIflZfl9afDfBJYyWhEHiEbbUp38PEfoDKs/9UbtnT4xs07+5aNU2jHdLfphb02A6ZU/XNS7sjsN0O5GQnGc9AV+XUpl2gxX1N+cLUbI2IKfAUIWZK1GD3bif6xRX6JFPoTMFfwacXoli3HriCRGek1+TXFAEK3wQ7QnYQg/3k9VBul7RXZheaUP49pjeojgmv0RzYZhcL+2PnzK3YILQFCEn08wn10hhN/uwvIlCCghPGN8h7YpuC4mFb/Sd7rspLKEXfrxqL1z44yPXF2xCekv89PGDXdlCtCEhuYF9FI7HCzn38WebQ355EF+m828VH+M539MmeBjMglXJ/znkjQazfILd2B0xbiih9XY2K7uy1qTQRaNR/nkKRvKPFZ2eLOJs5UWvFd0LbVwIJFZohfBjhVYIP1ZohfBjhVYIP97adCH6XVU4FV6fgBP8s6pQ+IA8pPxT+XsxHIkHktoP+jmpLty68In466/r6kJn/oiRBzgIj37/mtQROs5u2Gfm368g8t+vb5OLesLooMHMNyA5fdFsXSE7Uv9EZkMxX/hquvCa7zNDOHk1XDgRf+ledeHrNYy81vxWQX7KvpERSuy3e1oh/FihFcKPFVoh/FihFcKPFVoh/FghP4u2hy6ZRWWh0/bQJVNDqEdNc/9UkJJwocWVmtwUKgm1mMSb/KCVhBpcbuvlp1BRuAA/iwWgohD8R7EIVBXC/izeMIDqQrhNZfqqCCMjQOTNgu1znP8BkoJvrODeAzMAAAAASUVORK5CYII=" class="img-thumbnail w-25" alt="No Image">';
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <?php
                                                $pdfPath = $row['file'];
                                                $pdfFullPath = !empty($pdfPath) ? __DIR__ . '/' . $pdfPath : '';
                                                if (!empty($pdfPath) && file_exists($pdfFullPath)): ?>
                                                    <a href="<?= htmlspecialchars($pdfPath) ?>" class="btn btn-sm btn-outline-success" target="_blank">
                                                        <i class="fas fa-file-pdf me-1"></i> View PDF
                                                    </a>
                                                <?php else: ?>
                                                    <span class="text-muted"><i class="fas fa-file-pdf-slash"></i> No PDF</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="edit-news.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning me-1">Edit</a>
                                                <a href="delete-news.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger"
                                                   onclick="return confirm('Are you sure you want to delete this news?')">Delete</a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-warning text-center mb-0">
                            No news available.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
