<?php
include 'includes/db.php';
include 'links.php';

session_start();

$error = '';

// Check if user is already logged in
if (isset($_SESSION['username'])) {
    header("Location: dashboard.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $role = $_POST['role'];

    if ($username && $password && $role) {
        // Prepare the SQL statement
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? AND role = ?");
        $stmt->bind_param("ss", $username, $role);
        $stmt->execute();
        $res = $stmt->get_result();
        $user = $res->fetch_assoc();

        if ($user && password_verify($password, $user['password'])) {
            // Set session variables
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            header("Location: dashboard.php");
            exit;
        } else {
            $error = "Invalid username, password, or role.";
        }
    } else {
        $error = "All fields are required.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login | Admin Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
        
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #e9ecef;
        }
        .login-container {
            margin-top: 5%;
        }
        .login-card {
            border-radius: 12px;
            box-shadow: 0 6px 32px rgba(0, 0, 0, 0.12);
        }
        .card-header {
            background-color: #007bff;
            color: white;
            font-size: 1.5rem;
            text-align: center;
            padding: 1rem 0;
            border-top-left-radius: 12px;
            border-top-right-radius: 12px;
        }
        .eye-icon {
            cursor: pointer;
        }
    </style>
</head>
<body>

<div class="container login-container">
    <div class="row justify-content-center">
        <div class="col-lg-6 col-md-8">
            <div class="card login-card bg-white">
                <div class="card-header">Admin Login</div>
                <div class="card-body p-4">
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                    <?php endif; ?>

                    <form method="POST" novalidate>
                        <!-- Role -->
                        <div class="mb-3">
                            <label for="role" class="form-label">Select Role</label>
                            <select name="role" id="role" class="form-select" required>
                                <option value="">-- Choose Role --</option>
                                <option value="admin" <?= isset($_POST['role']) && $_POST['role'] == 'admin' ? 'selected' : '' ?>>Admin</option>
                                <option value="user" <?= isset($_POST['role']) && $_POST['role'] == 'user' ? 'selected' : '' ?>>User</option>
                            </select>
                        </div>

                        <!-- Username -->
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" name="username" id="username" class="form-control" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
                        </div>

                        <!-- Password -->
                        <div class="mb-3">
                            <label for="passwordField" class="form-label">Password</label>
                            <div class="input-group">
                                <input type="password" name="password" class="form-control" id="passwordField" required>
                                <span class="input-group-text" onclick="togglePassword()">
                                    <i class="bi bi-eye" id="toggleIcon"></i>
                                </span>
                            </div>
                        </div>

                        <!-- Submit -->
                        <button type="submit" class="btn btn-primary w-100">Login</button>

                        <!-- Register link -->
                        <div class="mt-3 text-center">
                            <small>Don't have an account? <a href="register.php">Register here</a></small>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Toggle password visibility -->
<script>
function togglePassword() {
    const passwordField = document.getElementById("passwordField");
    const toggleIcon = document.getElementById("toggleIcon");

    if (passwordField.type === "password") {
        passwordField.type = "text";
        toggleIcon.classList.replace("bi-eye", "bi-eye-slash");
    } else {
        passwordField.type = "password";
        toggleIcon.classList.replace("bi-eye-slash", "bi-eye");
    }
}
</script>

</body>
</html>
