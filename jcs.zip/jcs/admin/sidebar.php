<?php

$username = $_SESSION['username'] ?? 'Guest';
$role = $_SESSION['role'] ?? 'User';
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js"></script>

<nav class="navbar navbar-expand-lg navbar-light bg-light sticky-top ">
  <div class="container">
    <!-- Logo -->
    <a class="navbar-brand fw-bold" href="dashboard.php">Admin Panel</a>

    <!-- Toggler for mobile -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent"
      aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Navbar links -->
    <div class="collapse navbar-collapse" id="navbarContent">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">

        <!-- Dashboard -->
        <li class="nav-item">
          <a class="nav-link <?= $currentPage === 'dashboard.php' ? 'active' : '' ?>" href="dashboard.php">
            Dashboard
          </a>
        </li>

        <!-- Honours Dropdown -->
        <?php
        $honoursPages = [
          'student-of-the-year.php', 'isc_topper.php', 'icse_topper.php',
          'school_captain.php', 'sports_boy.php', 'sports_girl.php',
          'emerging_boy.php', 'emerging_girl.php'
        ];
        ?>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle <?= in_array($currentPage, $honoursPages) ? 'active' : '' ?>" href="#"
            id="honoursDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Honours Board
          </a>
          <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="honoursDropdown">
            <li><a class="dropdown-item" href="student-of-the-year.php">Student of the Year</a></li>
            <li><a class="dropdown-item" href="isc_topper.php">ISC Topper</a></li>
            <li><a class="dropdown-item" href="icse_topper.php">ICSE Topper</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="school_captain.php">School Captain</a></li>
            <li><a class="dropdown-item" href="sports_boy.php">Sports Boy</a></li>
            <li><a class="dropdown-item" href="sports_girl.php">Sports Girl</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="emerging_boy.php">Emerging Boy</a></li>
            <li><a class="dropdown-item" href="emerging_girl.php">Emerging Girl</a></li>
          </ul>
        </li>

        <!-- News -->
        <li class="nav-item">
          <a class="nav-link <?= $currentPage === 'news_list.php' ? 'active' : '' ?>" href="news_list.php">News</a>
        </li>

        <!-- User Dropdown -->
        <li class="nav-item dropdown">
          <a class="btn btn-outline-primary btn-sm dropdown-toggle ms-3" href="#" id="logoutDropdown"
            role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Welcome, <?= htmlspecialchars(ucfirst($username)) ?> (<?= htmlspecialchars($role) ?>)
          </a>
          <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="logoutDropdown">
            <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
          </ul>
        </li>

      </ul>
    </div>
  </div>
</nav>
