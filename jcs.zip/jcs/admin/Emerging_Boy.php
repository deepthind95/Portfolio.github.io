<?php
session_start();
include 'top.php';
include 'links.php';
include 'sidebar.php';
include 'includes/db.php';
$query = "SELECT * FROM students WHERE designation = 'Emerging Sports Boy Of the Year' ORDER BY id ASC LIMIT 10";
$result = mysqli_query($conn, $query);

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  
  <link rel="stylesheet" href="css/style.css">
  <title>Jogindra Convent School</title>



</head>
<div class="container-fluid mt-1 image1">
  <div class="position-relative">
    <div class="carousel-overlay position-absolute  start-0 w-100 h-100 bg-dark opacity-50"></div>
    <img src="img/slider-01.jpg" class="image" alt="">
    <div class="carousel-caption text-end position-absolute top-50 start-50 translate-middle text-light">

      <h2 class="fw-bold text-uppercase">Emerging Sports Boy of the Year</h2>




    </div>
  </div>
  <div class="my-3"></div>
  <section class="section-container container">
</div>

  <div class="modal fade" id="insertModal" tabindex="-1" role="dialog" aria-labelledby="modalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <form action="insert.php" method="POST" enctype="multipart/form-data">
        <div class="modal-content p-3">
          <div class="modal-header">
            <h5 class="modal-title" id="modalTitle">Insert Student</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="mb-3">
              <label for="studentName" class="form-label">Student Name:</label>
              <input type="text" name="student_name" id="studentName" class="form-control" required>
            </div>
            <div class="mb-3">
              <label for="designation" class="form-label">Designation:</label>
              <select name="designation" id="designation" class="form-select" required>
                <option value="">Select Designation</option>
                <option value="Student of the Year">STUDENT OF THE YEAR</option>
                <option value="ISC Topper">ISC Topper</option>
                <option value="ICSE Topper">ICSE Topper</option>
                <option value="School Captain">School Captain</option>
                <option value="Sports Boy Of The Year">Sports Boy Of The Year</option>
                <option value="Sports Boy Of The Year">Sports Girl Of The Year</option>
                <option value="Emerging Sportsboy Of The Year">Emerging Sportsboy Of The Year</option>
                <option value="Emerging Sportsgirl Of The Year">Emerging Sportsgirl Of The Year</option>
              </select>
            </div>
            <div class="mb-3">
              <label for="session" class="form-label">Session:</label>
              <select name="session" id="session" class="form-select" required>
                <option value="">Select Session</option>
                <?php
                for ($year = 2016; $year <= 2030; $year++) {
                  $nextYear = $year + 1;
                  echo "<option value='{$year}-{$nextYear}'>{$year}-{$nextYear}</option>";
                }
                ?>
              </select>
            </div>
            <div class="mb-3">
              <label for="studentPhoto" class="form-label">Student Photo:</label>
              <input type="file" name="student_photo" id="studentPhoto" class="form-control" accept="image/*" required>
            </div>
          </div>
          <div class="modal-footer">
            <button type="submit" name="save" class="btn btn-success">Save</button>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</section>


<!-- Table to Display Students -->
<div class="container mt-4">
  <div class="d-flex justify-content-end mb-3">
    <button type="button" class="btn btn-success px-4 py-2 rounded-pill shadow" data-bs-toggle="modal" data-bs-target="#insertModal">
      <i class="fas fa-star me-2"></i> Add Emerging Sports Boy
    </button>
  </div>
</div>

    <table id="studentTable" class="table text-center table-bordered table-danger my-3">
      <thead>
      <tr class="table-dark">
      <th>#</th>
      <th>Photo</th>
      <th>Student Name</th>
      <th>Designation</th>
      <th>Session</th>
      <th>Actions</th>
      </tr>
      </thead>
      <tbody>
      <?php
      $id = 0;
      while ($row = mysqli_fetch_assoc($result)) {
      $id++;
      ?>
      <tr>
      <td><?= $id; ?></td>
      <td><img src="<?php echo htmlspecialchars("uploads/".$row['student_photo']); ?>" class="img-fluid img-thumbnail" width="50" alt="Student Photo"></td>
      <td><?php echo htmlspecialchars($row['student_name']); ?></td>
      <td><?php echo htmlspecialchars($row['designation']); ?></td>
      <td><?php echo htmlspecialchars($row['session']); ?></td>
      <td>
      <a href="Emerging_Boy_edit.php ?id=<?php echo $row['id']; ?>" class="btn btn-warning">Edit</a>
      <a href="delete_student.php?id=<?php echo $row['id']; ?>" class="btn btn-danger">Delete</a>
      </td>
    </tr>
    <?php } ?>
  </tbody>
  
    </table>
    <script>
  $(document).ready(function () {
    $('#studentTable').DataTable({
      pageLength: 10,
      lengthMenu: [5, 10, 25, 50],
      dom: 'Bfrtip',
      buttons: [
        {
          extend: 'copy',
          className: 'btn btn-secondary mx-1'
        },
        {
          extend: 'csv',
          className: 'btn btn-danger mx-1'
        },
        {
          extend: 'excel',
          className: 'btn btn-success mx-1'
        },
        {
          extend: 'pdf',
          className: 'btn btn-info mx-1'
        },
        {
          extend: 'print',
          className: 'btn btn-warning mx-1',
          exportOptions: {
            columns: ':visible'
          }
        },
        {
          extend: 'colvis',
          className: 'btn btn-danger',
          text: 'Toggle Columns'
        }
      ]
    });
  });
</script>
  


<?php include 'footer.php'; ?>