<?php
include 'includes/db.php';

$id = $_GET['id'];

// Get current photo name to delete the file
$result = $conn->query("SELECT student_photo FROM students WHERE id=$id");
$row = $result->fetch_assoc();
$photo = $row['student_photo'];

// Delete photo file
if ($photo && file_exists("uploads/$photo")) {
    unlink("uploads/$photo");
}

// Delete from DB
$conn->query("DELETE FROM students WHERE id=$id");

echo "<script>alert('Student deleted successfully'); window.location='dashboard.php';</script>";
?>
        