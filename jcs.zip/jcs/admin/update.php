<?php
include 'includes/db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['id'])) {
    $id = (int) $_POST['id'];
    $title = trim($conn->real_escape_string($_POST["title"]));
    $link = trim($conn->real_escape_string($_POST["link"]));
    $description = trim($conn->real_escape_string($_POST["description"]));
    $image = $_POST['existing_image'] ?? ''; // fallback if not set

    // Check and handle file upload
    if (isset($_FILES["image"]) && $_FILES["image"]["name"] !== '') {
        $targetDir = "uploads/news/";
        $fileName = basename($_FILES["image"]["name"]);
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $allowedTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

        if (in_array($fileExt, $allowedTypes)) {
            // Unique file name to prevent overwriting
            $newFileName = uniqid('news_', true) . "." . $fileExt;
            $targetFile = $targetDir . $newFileName;

            // Move uploaded file
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
                $image = $newFileName;
            } else {
                die("Error uploading the image.");
            }
        } else {
            die("Invalid image file type. Allowed: " . implode(', ', $allowedTypes));
        }
    }

    // Use prepared statements for better security
    $stmt = $conn->prepare("UPDATE news SET title = ?, link = ?, description = ?, image = ? WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param("ssssi", $title, $link, $description, $image, $id);
        if ($stmt->execute()) {
            header("Location: index.php?status=updated");
            exit();
        } else {
            echo "Execution error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Prepare failed: " . $conn->error;
    }
} else {
    echo "Invalid Request";
}
?>
