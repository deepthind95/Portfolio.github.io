<?php include'includes/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST["title"];
    $link = $_POST["link"];
    $description = $_POST["description"];
    $image = '';

    if ($_FILES["image"]["name"]) {
        $targetDir = "uploads/news";
        $image = basename($_FILES["image"]["name"]);
        $targetFile = $targetDir . $image;
        move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile);
    }

    $sql = "INSERT INTO news (title, link, description, image) VALUES ('$title', '$link', '$description', '$targetFile')";
    $conn->query($sql);
    header("Location: news_list.php");
}
?>