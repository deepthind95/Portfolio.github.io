<?php
include 'includes/db.php';

$id = $_POST['id'];
$name = $_POST['student_name'];
$session = $_POST['session'];
$designation = $_POST['designation'];

// Handle file upload
if (!empty($_FILES['student_photo']['name'])) {
    $photo = time() . "_" . basename($_FILES["student_photo"]["name"]);
    $target = "uploads/" . $photo;
    move_uploaded_file($_FILES["student_photo"]["tmp_name"], $target);

    $sql = "UPDATE students SET 
                student_name = '$name', 
                session = '$session', 
                designation = '$designation', 
                student_photo = '$target' 
            WHERE id = $id";
} else {
    $sql = "UPDATE students SET 
                student_name = '$name', 
                session = '$session', 
                designation = '$designation'
            WHERE id = $id";
}

if ($conn->query($sql)) {
    echo "<script>
            alert('Student updated successfully');
            window.location = 'dashboard.php';
          </script>";
} else {
    echo "Error: {$conn->error}";
}
