<?php
include 'includes/db.php';

if (isset($_POST['save'])) {
    $student_name = $_POST['student_name'];
    $designation = $_POST['designation'];
    $session = $_POST['session'];
    $photo = $_FILES['student_photo'];

    $target_dir = "uploads/";
    $target_file = $target_dir . time() . "_" . basename($photo["name"]); // Prevent duplicate filenames
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    $check = getimagesize($photo["tmp_name"]);

    // Function to show SweetAlert2 and exit
    function showAlert($type, $title, $text, $redirect = null) {
        echo "
        <!DOCTYPE html>
        <html>
        <head>
        </head>
        <body>
        <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
        <script>
        Swal.fire({
            icon: '$type',
            title: '$title',
            text: '$text',
            confirmButtonText: 'OK'
        }).then(() => {
            " . ($redirect ? "window.location.href = '$redirect';" : "window.history.back();") . "
        });
        </script>
        </body>
        </html>";
        exit;
    }

    // Validation
    if ($check === false) {
        showAlert('error', 'Invalid File', 'Uploaded file is not an image.');
    }

    if ($photo["size"] > 2000000) {
        showAlert('error', 'File Too Large', 'Maximum allowed size is 2MB.');
    }

    if (!in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif'])) {
        showAlert('error', 'Invalid Format', 'Only JPG, JPEG, PNG & GIF files are allowed.');
    }

    if (!move_uploaded_file($photo["tmp_name"], $target_file)) {
        showAlert('error', 'Upload Failed', 'There was a problem uploading your file.');
    }

    // Insert into database
    $stmt = $conn->prepare("INSERT INTO students (student_name, designation, session, student_photo) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $student_name, $designation, $session, $target_file);

    if ($stmt->execute()) {
        showAlert('success', 'Success', 'Student record added successfully!', 'dashboard.php');
    } else {
        showAlert('error', 'Database Error', 'Failed to insert data.');
    }

    $stmt->close();
    $conn->close();
}
?>

