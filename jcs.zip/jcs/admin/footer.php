<!-- Admin Panel Footer -->
<footer class="bg-white border-top py-3 mt-auto shadow-sm">
    <div class="container-fluid text-center">
        <span class="text-muted small">
            &copy; <?php echo date('Y'); ?> Jogindra Convent School Admin Panel. All rights reserved.
        </span>
    </div>
</footer>
