<?php
include 'includes/db.php';
$id = $_GET['id'];
$conn->query("DELETE FROM news WHERE id = $id");
header('Location: news_list.php');
?>