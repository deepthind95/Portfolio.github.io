<?php include 'top.php';
include 'links.php';
include 'navbar.php';
?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css" rel="stylesheet">
<!-- filepath: c:\xampp\htdocs\jcs\photo-gallery.php -->
<section class="section-container">
    <div class="container">
        <h1 class="text-center my-3">Our Gallery</h1>
        <div class="row">
            <!-- Image 1 -->
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-1.jpg" data-lightbox="gallery" data-title="Image 1">
                    <img src="img/jc-1.jpg" class="img-fluid img-thumbnail" alt="Image 1">
                </a>
            </div>
            <!-- Image 2 -->
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-2.jpg" data-lightbox="gallery" data-title="Image 2">
                    <img src="img/jc-2.jpg" class="img-fluid img-thumbnail" alt="Image 2">
                </a>
            </div>
            <!-- Image 3 -->
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-3.jpg" data-lightbox="gallery" data-title="Image 3">
                    <img src="img/jc-3.jpg" class="img-fluid img-thumbnail" alt="Image 3">
                </a>
            </div>
            <!-- Image 4 -->
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-4.jpg" data-lightbox="gallery" data-title="Image 4">
                    <img src="img/jc-4.jpg" class="img-fluid img-thumbnail" alt="Image 4">
                </a>
            </div>
        </div>

        <div class="row">
            <!-- Add more images as needed -->
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-5.jpg" data-lightbox="gallery" data-title="Image 5">
                    <img src="img/jc-5.jpg" class="img-fluid img-thumbnail" alt="Image 5">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-6.jpg" data-lightbox="gallery" data-title="Image 6">
                    <img src="img/jc-6.jpg" class="img-fluid img-thumbnail" alt="Image 6">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-7.jpg" data-lightbox="gallery" data-title="Image 7">
                    <img src="img/jc-7.jpg" class="img-fluid img-thumbnail" alt="Image 7">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-8.jpg" data-lightbox="gallery" data-title="Image 8">
                    <img src="img/jc-8.jpg" class="img-fluid img-thumbnail" alt="Image 8">
                </a>
            </div>
        </div>
        <div class="row">
            <!-- Add more images as needed -->
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-19.jpg" data-lightbox="gallery" data-title="Image 5">
                    <img src="img/jc-19.jpg" class="img-fluid img-thumbnail" alt="Image 5">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-10.jpg" data-lightbox="gallery" data-title="Image 6">
                    <img src="img/jc-10.jpg" class="img-fluid img-thumbnail" alt="Image 6">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-11.jpg" data-lightbox="gallery" data-title="Image 7">
                    <img src="img/jc-11.jpg" class="img-fluid img-thumbnail" alt="Image 7">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-12.jpg" data-lightbox="gallery" data-title="Image 8">
                    <img src="img/jc-12.jpg" class="img-fluid img-thumbnail" alt="Image 8">
                </a>
            </div>
        </div>
        <div class="row">
            <!-- Add more images as needed -->
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-13.jpg" data-lightbox="gallery" data-title="Image 5">
                    <img src="img/jc-13.jpg" class="img-fluid img-thumbnail" alt="Image 5">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-14.jpg" data-lightbox="gallery" data-title="Image 6">
                    <img src="img/jc-14.jpg" class="img-fluid img-thumbnail" alt="Image 6">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-15.jpg" data-lightbox="gallery" data-title="Image 7">
                    <img src="img/jc-15.jpg" class="img-fluid img-thumbnail" alt="Image 7">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-16.jpg" data-lightbox="gallery" data-title="Image 8">
                    <img src="img/jc-16.jpg" class="img-fluid img-thumbnail" alt="Image 8">
                </a>
            </div>
        </div>
        <div class="row">
            <!-- Add more images as needed -->
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-17.jpg" data-lightbox="gallery" data-title="Image 5">
                    <img src="img/jc-17.jpg" class="img-fluid img-thumbnail" alt="Image 5">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-18.jpg" data-lightbox="gallery" data-title="Image 6">
                    <img src="img/jc-18.jpg" class="img-fluid img-thumbnail" alt="Image 6">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-19.jpg" data-lightbox="gallery" data-title="Image 7">
                    <img src="img/jc-19.jpg" class="img-fluid img-thumbnail" alt="Image 7">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-20.jpg" data-lightbox="gallery" data-title="Image 8">
                    <img src="img/jc-20.jpg" class="img-fluid img-thumbnail" alt="Image 8">
                </a>
            </div>
        </div>
        <div class="row">
            <!-- Add more images as needed -->
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-21.jpg" data-lightbox="gallery" data-title="Image 5">
                    <img src="img/jc-21.jpg" class="img-fluid img-thumbnail" alt="Image 5">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-22.jpg" data-lightbox="gallery" data-title="Image 6">
                    <img src="img/jc-22.jpg" class="img-fluid img-thumbnail" alt="Image 6">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-23.jpg" data-lightbox="gallery" data-title="Image 7">
                    <img src="img/jc-23.jpg" class="img-fluid img-thumbnail" alt="Image 7">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-24.jpg" data-lightbox="gallery" data-title="Image 8">
                    <img src="img/jc-24.jpg" class="img-fluid img-thumbnail" alt="Image 8">
                </a>
            </div>
        </div>
        <div class="row">
            <!-- Add more images as needed -->
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-30.jpg" data-lightbox="gallery" data-title="Image 5">
                    <img src="img/jc-30.jpg" class="img-fluid img-thumbnail" alt="Image 5">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-26.jpg" data-lightbox="gallery" data-title="Image 6">
                    <img src="img/jc-26.jpg" class="img-fluid img-thumbnail" alt="Image 6">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-27.jpg" data-lightbox="gallery" data-title="Image 7">
                    <img src="img/jc-27.jpg" class="img-fluid img-thumbnail" alt="Image 7">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-28.jpg" data-lightbox="gallery" data-title="Image 8">
                    <img src="img/jc-28.jpg" class="img-fluid img-thumbnail" alt="Image 8">
                </a>
            </div>
        </div>
        <div class="row">
            <!-- Add more images as needed -->
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-29.jpg" data-lightbox="gallery" data-title="Image 5">
                    <img src="img/jc-29.jpg" class="img-fluid img-thumbnail" alt="Image 5">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-30.jpg" data-lightbox="gallery" data-title="Image 6">
                    <img src="img/jc-30.jpg" class="img-fluid img-thumbnail" alt="Image 6">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-31.jpg" data-lightbox="gallery" data-title="Image 7">
                    <img src="img/jc-31.jpg" class="img-fluid img-thumbnail" alt="Image 7">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-32.jpg" data-lightbox="gallery" data-title="Image 8">
                    <img src="img/jc-32.jpg" class="img-fluid img-thumbnail" alt="Image 8">
                </a>
            </div>
        </div>
        <div class="row">
            <!-- Add more images as needed -->
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-33.jpg" data-lightbox="gallery" data-title="Image 5">
                    <img src="img/jc-33.jpg" class="img-fluid img-thumbnail" alt="Image 5">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-34.jpg" data-lightbox="gallery" data-title="Image 6">
                    <img src="img/jc-34.jpg" class="img-fluid img-thumbnail" alt="Image 6">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-35.jpg" data-lightbox="gallery" data-title="Image 7">
                    <img src="img/jc-35.jpg" class="img-fluid img-thumbnail" alt="Image 7">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <a href="img/jc-20.jpg" data-lightbox="gallery" data-title="Image 8">
                    <img src="img/jc-20.jpg" class="img-fluid img-thumbnail" alt="Image 8">
                </a>
            </div>
        </div>
    </div>
</section>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>
<?php include 'footer.php';
?>