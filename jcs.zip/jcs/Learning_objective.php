<?php include 'links.php'; ?>
<section class="section-container py-5">
    <div class="container-fluid">
        <h1 class="text-center">Learning Objectives</h1>

        <div class="owl-carousel owl-theme">
            <!-- Card 1 -->
            <div class="item">
                <div class="card">
                    <img src="img/local-moving.jpg" class="card-img-top img-fluid" alt="Card 1">
                    <div class="card-body">
                        <h5 class="card-title">Library</h5>

                        <a href="#" class="btn btn-primary">Read More</a>
                    </div>
                </div>
            </div>
            <!-- Card 2 -->
            <div class="col-md-4">
                <div class="card">
                    <img src="img/sdk.jpg" class="card-img-top" alt="Card 2">
                    <div class="card-body">
                        <h5 class="card-title">Laboratories</h5>

                        <a href="#" class="btn btn-primary">Read More</a>
                    </div>
                </div>
            </div>
            <!-- Card 3 -->
            <div class="col-md-4">
                <div class="card">
                    <img src="img/asiofjaij.jpg" class="card-img-top" alt="Card 3">
                    <div class="card-body">
                        <h5 class="card-title">Sports</h5>

                        <a href="#" class="btn btn-primary">Read More</a>
                    </div>
                </div>
            </div>
            <!-- Card 4 -->
            <div class="col-md-4">
                <div class="card">
                    <img src="img/iedviom.jpg" class="card-img-top" alt="Card 4">
                    <div class="card-body">
                        <h5 class="card-title">Computer Lab</h5>

                        <a href="#" class="btn btn-primary">Read More</a>
                    </div>
                </div>
            </div>
            <!-- Card 5 -->
            <div class="col-md-4">
                <div class="card">
                    <img src="img/fgjiodo.jpg" class="card-img-top" alt="Card 5">
                    <div class="card-body">
                        <h5 class="card-title">Co-Curricular Activities</h5>

                        <a href="#" class="btn btn-primary">Read More</a>
                    </div>
                </div>
            </div>
            <!-- Card 6 -->
            <div class="col-md-4">
                <div class="card">
                    <img src="img/eksicmsom.jpg" class="card-img-top" alt="Card 6">
                    <div class="card-body">
                        <h5 class="card-title">Transport</h5>

                        <a href="#" class="btn btn-primary">Read More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</section>