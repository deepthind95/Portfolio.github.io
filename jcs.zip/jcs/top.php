<?php include 'links.php'; ?>
<!-- Header -->
<div class="container-fluid py-2 main-header">
    <div class="container">
        <div class="row align-items-center justify-content-between g-3">
            
            <!-- Logo & School Details -->
            <div class="col-md-8 d-flex align-items-center gap-4 py-3">
                <!-- Logo -->
                <div class="text-center flex-shrink-0">
                    <img src="img/logo1.png" alt="Jogindra Convent School Logo" class="img-fluid" style="max-height: 100px;">
                </div>

                <!-- School Info -->
                <div class="text-start">
                    <h2 class="text-warning fw-bold">Jogindra Convent School</h2>
                    <h5 class="text-info fw-semibold">Affiliation: ICSE & ISC School</h5>
                    <h6 class="text-primary fw-normal">Commerce · Humanities · Science</h6>
                </div>
            </div>

            <!-- Login & Location Buttons -->
            <div class="col-md-4 text-center text-md-end">
                <div class="d-inline-flex flex-wrap gap-2 justify-content-center justify-content-md-end">
                    <a href="https://jcsfzr.schoolpad.in/loginManager/load" target="_blank" class="btn btn-sm btn-outline-primary shadow-sm transition rounded-pill px-3" aria-label="Student or Parent Login">
                        <i class="fas fa-user-circle me-1"></i> Student / Parent Login
                    </a>
                    <a href="https://maps.app.goo.gl/oDUHTP2JKJECTBzk7" target="_blank" class="btn btn-sm btn-outline-success shadow-sm transition rounded-pill px-3" aria-label="View Location on Map">
                        <i class="fas fa-map-marker-alt me-1"></i> Location Map
                    </a>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Floating Action Buttons -->
<div class="floating-buttons position-fixed">
    <!-- Call Button -->
    <a href="tel:+919478850505" 
       class="btn btn-danger btn-sm d-flex align-items-center shadow-sm text-white mb-2 transition px-3" 
       title="Call Now" 
       aria-label="Call Now">
        <i class="fas fa-phone fs-5"></i>
        <span class="ms-2 d-none d-md-inline">Call Us</span>
    </a>

    <!-- WhatsApp Button -->
    <a href="https://wa.me/919478850505" 
       target="_blank" 
       class="btn btn-success btn-sm d-flex align-items-center shadow-sm text-white transition px-3" 
       title="Chat on WhatsApp" 
       aria-label="Chat on WhatsApp">
        <i class="fab fa-whatsapp fs-5"></i>
        <span class="ms-2 d-none d-md-inline">Chat Now</span>
    </a>
</div>
