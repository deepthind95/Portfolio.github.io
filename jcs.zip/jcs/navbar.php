<?php include 'links.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>School Navigation</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg sticky-top bg-dark navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php"><img src="img/logo1.png" class="rounded-circle  img-thumbnail w-50 " alt=""></a> <!-- Add your school logo or name here -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                    </li>

                    <!-- About Us Dropdown -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            About Us
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="chairman_message.php">Chairman's Message</a></li>
                            <li><a class="dropdown-item" href="principal.php">Principal’s Message</a></li>
                            <li><a class="dropdown-item" href="vision-mission.php">Vision & Mission</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="aims.php">Aims and Objectives</a></li>
                            <li><a class="dropdown-item" href="#">Important Features</a></li>
                            <li><a class="dropdown-item" href="#">Awards and Scholarships</a></li>
                            <li><a class="dropdown-item" href="#">Meet Our Team</a></li>
                        </ul>
                    </li>

                    <!-- School Currere Dropdown -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            School Currere
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="kindergarten.html">Kindergarten</a></li>
                            <li><a class="dropdown-item" href="primary-school.html">Primary School</a></li>
                            <li><a class="dropdown-item" href="middle-school.html">Middle School</a></li>
                            <li><a class="dropdown-item" href="high-school.html">High School (ICSE)</a></li>
                            <li><a class="dropdown-item" href="sr-secondary.html">Sr. Secondary (ISC)</a></li>
                        </ul>
                    </li>

                    <!-- Facilities Dropdown -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Facilities
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="library.html">Library</a></li>
                            <li><a class="dropdown-item" href="laboratorium.html">Laboratorium</a></li>
                            <li><a class="dropdown-item" href="mathematics-laboratory.html">Mathematics Laboratory</a></li>
                            <li><a class="dropdown-item" href="computer-lab.html">Computer Lab</a></li>
                            <li><a class="dropdown-item" href="smart-class.html">Smart Class</a></li>
                            <li><a class="dropdown-item" href="co-curricular-activities.html">Co-Curricular Activities</a></li>
                            <li><a class="dropdown-item" href="transport.html">Transport</a></li>
                        </ul>
                    </li>

                    <!-- Activities Dropdown -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Activities
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="house-system.html">House System</a></li>
                            <li><a class="dropdown-item" href="student-council.html">Student Council</a></li>
                            <li><a class="dropdown-item" href="sports.html">Sports</a></li>
                            <li><a class="dropdown-item" href="indoor-games.html">Indoor Games</a></li>
                            <li><a class="dropdown-item" href="outdoor-games.html">Outdoor Games</a></li>
                            <li><a class="dropdown-item" href="athletics.html">Athletics</a></li>
                            <li><a class="dropdown-item" href="leadership-development.html">Leadership Development</a></li>
                            <li><a class="dropdown-item" href="inter-house-activities.html">Inter-House Activities</a></li>
                        </ul>
                    </li>

                    <!-- Honours Board Dropdown -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Honours Board
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="student-of-the-year.php">Student of the Year</a></li>
                            <li><a class="dropdown-item" href="Isc_topper.php">ISC Topper</a></li>
                            <li><a class="dropdown-item" href="Icse_Topper.php">ICSE Topper</a></li>
                            <li><a class="dropdown-item" href="School_captain.php">School Captain</a></li>
                            <li><a class="dropdown-item" href="img/Honours%20Board%20Students%20Council%20(1).pdf" target="_blank">Student Council</a></li>
                            <li><a class="dropdown-item" href="img/house-of-the-year-25.pdf" target="_blank">House of the Year</a></li>
                            <li><a class="dropdown-item" href="Sports_Boy.php">Sports Boy of the year</a></li>
                            <li><a class="dropdown-item" href="Sports_Girl.php">Sports Girl of the year</a></li>
                            <li><a class="dropdown-item" href="Emerging_Boy.php">Emerging Sports Boy of the Year</a></li>
                            <li><a class="dropdown-item" href="Emerging_Girl.php">Emerging Sports Girl of the Year</a></li>
                        </ul>
                    </li>

                    <!-- Gallery Dropdown -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Gallery
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="video-gallery.html">Video Gallery</a></li>
                            <li><a class="dropdown-item" href="photo-gallery.php">Photo Gallery</a></li>
                            <li><a class="dropdown-item" href="education-tour.html">Education Tour</a></li>
                        </ul>
                    </li>

                    <!-- Notice Board Dropdown -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Notice Board
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="pdf/fee-structure-2025-26.pdf" target="_blank">Fee Structure 2025-26</a></li>
                            <li><a class="dropdown-item" href="entrance-exam-syllabus.html">Entrance Exam Syllabus</a></li>
                            <li><a class="dropdown-item" href="book-list.html">Book List (2024-25)</a></li>
                            <li><a class="dropdown-item" href="date-sheet.html">Date Sheet</a></li>
                            <li><a class="dropdown-item" href="results.html">Results</a></li>
                            <li><a class="dropdown-item" href="syllabus.html">Syllabus (2024-25)</a></li>
                            <li><a class="dropdown-item" href="regular-uniform.html">Regular Uniform</a></li>
                            <li><a class="dropdown-item" href="house-wise-uniform.html">House Wise Uniform</a></li>
                            <li><a class="dropdown-item" href="pdf/planner-2024-25.pdf" target="_blank">Planner 2024-25</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Add your content here -->

    <!-- Bootstrap JS and Popper -->

</body>

</html>
