<?php 
include 'top.php';
include 'links.php';
include 'navbar.php';
?>
<section class="py-5 section-container  ">
    <div class="container-fluid">
        <div class="row">
            <!-- 30% Column -->

            <!-- 70% Column -->
            <div class="col-md-8">

                <h1 class="text-uppercase">From Principal's Desk</h1>
                <div class="border border-dark  w-25"></div>
                <p class=" text-break text-justify text bg-light">Today, the role of a school is not only to pursue
                    the academic excellence but also to motivate and empower the students to be lifelong learners,
                    critical thinkers, and productive members o' n ever-changing global society. Converting every
                    individual into a self-reliant and independent citizen, our school provides an amalgam of
                    scholastic and co-scholastic activities. The world today is changing at such an accelerated rate
                    and we as educator need to pause and reflect on this entire system of Education. "To Motivate
                    the Late bloomers o mould the Mediocre and To Challenge the Gifted" is the teaching notion....
                </p>
                <h4 class="">Simrandeep Singh Dhaliwal</h4>
                <h5 class="bg-light text-dark  p-2 w-50 my-2">M.A. (English) M.Ed..</h5>
            


            </div>
            <div class="col-md-4">
                <img src="img/wdjiscji.jpg" class="img-fluid img-thumbnail w-100 img3 " alt="School Building">
            </div>
        </div>
    </div>
</section>
<?php include 'footer.php'; ?>