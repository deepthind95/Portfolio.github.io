<?php

include 'top.php';
include 'links.php';
include 'includes/db.php';
include 'navbar.php';
$query = "SELECT * FROM students WHERE designation = 'STUDENT OF THE YEAR' ORDER BY id ASC LIMIT 10";
$result = mysqli_query($conn, $query);
$dir = "uploads/"

  ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">


  <link rel="stylesheet" href="css/style.css">
  <title>Jogindra Convent School</title>
</head>

<div class="container-fluid mt-1 image1">
  <div class="position-relative">
    <div class="carousel-overlay position-absolute  start-0 w-100 h-100 bg-dark opacity-50"></div>
    <img src="img/slider-01.jpg" class="image" alt="">
    <div class="carousel-caption text-end position-absolute top-50 start-50 translate-middle text-light">

      <h2 class="fw-bold text-uppercase">Student of the year</h2>
</div>
  </div>

  <div class="container my-3">
    <table id="studentTable" class="table text-center table-bordered table-info ">
      <thead>
        <tr class="table-dark">
        <th>#</th>
        <th>Photo</th>
        <th>Student Name</th>
        <th>Designation</th>
        <th>Session</th>
      </tr>
    </thead>
    <tbody>
      <?php if (mysqli_num_rows($result) > 0): ?>
        <?php $id = 0; ?>
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
          <?php $id++; ?>
          <tr>
            <td><?= $id; ?></td>
            <td>
              <img src="<?= htmlspecialchars("admin/".$row['student_photo']); ?>" class="img-fluid img-thumbnail" width="80"
                alt="Student Photo">
            </td>
            <td><?= htmlspecialchars($row['student_name']); ?></td>
            <td><?= htmlspecialchars($row['designation']); ?></td>
            <td><?= htmlspecialchars($row['session']); ?></td>

          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr>
          <td colspan="6" class="text-center">No records found.</td>
        </tr>
      <?php endif; ?>
    </tbody>

  </table>

</div>
<?php include 'footer.php'; ?>