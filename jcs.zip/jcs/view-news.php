<?php
include 'includes/db.php';
include 'links.php';    
include 'top.php';

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $news_id = intval($_GET['id']);

    $stmt = $conn->prepare("SELECT * FROM news WHERE id = ?");
    $stmt->bind_param("i", $news_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $news = $result->fetch_assoc();
    } else {
        echo "<div class='alert alert-danger text-center mt-4'>News not found!</div>";
        exit;
    }
} else {
    echo "<div class='alert alert-danger text-center mt-4'>Invalid request!</div>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($news['title']) ?> | News</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Custom Styles -->
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .news-card {
            border: none;
            border-radius: 15px;
            overflow: hidden;
        }
        .news-image {
            border-radius: 10px;
            object-fit: cover;
            height: 100%;
            width: 100%;
        }
        .back-btn {
            margin-bottom: 25px;
        }
        .news-content p {
            font-size: 1.1rem;
            line-height: 1.7;
        }
    </style>
</head>
<body>

<div class="container py-5">
    <a href="index.php" class="btn btn-outline-secondary back-btn">&larr; Back to Home</a>

    <div class="card shadow-lg news-card">
        <div class="card-body p-4">
            <h2 class="text-primary mb-3"><?= htmlspecialchars($news['title']) ?></h2>
            <p class="text-muted"><i class="bi bi-calendar-event"></i> Posted on: <?= date("F j, Y", strtotime($news['created_at'] ?? 'now')) ?></p>

            <div class="row align-items-start">
                <!-- Image -->
                <?php if (!empty($news['image'])): ?>
                <div class="col-md-5 mb-4">
                    <img src="admin/<?= htmlspecialchars($news['image']) ?>" alt="News Image" class="news-image img-fluid shadow-sm">
                </div>
                <?php endif; ?>

                <!-- Description -->
                <div class="col-md-7 news-content">
                    <?php if (!empty($news['description'])): ?>
                        <p><?= nl2br(htmlspecialchars($news['description'])) ?></p>
                    <?php endif; ?>

                    <?php if (!empty($news['link'])): ?>
                        <a href="<?= htmlspecialchars($news['link']) ?>" class="btn btn-primary mt-3" target="_blank">
                            Read Full Article
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap Icons (optional) -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</body>
</html>
    