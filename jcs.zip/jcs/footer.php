<!-- Footer Section -->
<footer class="bg-dark text-light pt-5 pb-4">
    <div class="container">
        <div class="row text-center text-md-start">
            <!-- Logo and About Section -->
            <div class="col-md-3 mb-4">
                <img src="img/logo1.png" alt="Jogindra Convent School Logo" class="img-fluid mb-3 mx-auto d-block" style="max-width: 300px;">
                <h5 class="fw-bold">Jogindra Convent School</h5>
                <p>Early education gaining new dimensions to lead in an intensely competitive, technology-driven global environment.</p>
                <h6 class="fw-bold mt-4">Follow Us</h6>
                <div class="d-flex justify-content-center justify-content-md-start gap-3 social-icons fs-4">
                    <a href="https://www.facebook.com/jcs.fzr/" target="_blank" class="text-light" aria-label="Facebook"><i class="fab fa-facebook"></i></a>
                    <a href="https://x.com/i/flow/login?redirect_after_login=%2FJogindraSchool" target="_blank" class="text-light" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                    <a href="https://www.youtube.com/channel/UCm8_5OAR1oAjFa_kvREEe_Q" target="_blank" class="text-light" aria-label="YouTube"><i class="fab fa-youtube"></i></a>
                    <a href="https://www.instagram.com/jcsfzr/" target="_blank" class="text-light" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/company/jogindra-convent-school-ferozepur/" target="_blank" class="text-light" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>

            <!-- Quick Links -->
            <div class="col-md-3 mb-4">
                <h5 class="fw-bold">Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-light text-decoration-none">→ Home</a></li>
                    <li><a href="#" class="text-light text-decoration-none">→ About Us</a></li>
                    <li><a href="#" class="text-light text-decoration-none">→ Vision & Mission</a></li>
                    <li><a href="#" class="text-light text-decoration-none">→ Downloads</a></li>
                    <li><a href="#" class="text-light text-decoration-none">→ Admission</a></li>
                </ul>
            </div>

            <!-- More Links -->
            <div class="col-md-3 mb-4">
                <h5 class="fw-bold">More Links</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-light text-decoration-none">→ Library</a></li>
                    <li><a href="#" class="text-light text-decoration-none">→ Laboratories</a></li>
                    <li><a href="#" class="text-light text-decoration-none">→ Computer Lab</a></li>
                    <li><a href="#" class="text-light text-decoration-none">→ Student Council</a></li>
                    <li><a href="#" class="text-light text-decoration-none">→ Contact Us</a></li>
                </ul>
            </div>

            <!-- Contact Info -->
            <div class="col-md-3 mb-4">
                <h5 class="fw-bold">Contact Us</h5>
                <address class="text-white mb-2">
                    Jogindergarh, Badhni Gulab Singh, Moga Road, Ferozpur-142056 (Punjab)
                </address>
                <p>Email: <a href="mailto:info@jcsfzr.com" class="text-light text-decoration-none">info@jcsfzr.com</a></p>
                <p>Phone: <a href="tel:+919478950505" class="text-light text-decoration-none">+91 94789-50505</a></p>
            </div>
        </div>

        <!-- Footer Bottom -->
        <div class="text-center border-top border-secondary pt-3 mt-4">
            <p class="mb-0">&copy; <?php echo date('Y'); ?> Jogindra Convent School. All Rights Reserved.</p>
        </div>
    </div>
</footer>
