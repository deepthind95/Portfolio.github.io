<?php include 'top_links.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-2">
                <?php include 'sidebar.php'; ?>
            </div>
            <div class="col-sm-10">
                <section class="py-1 section-container section_heading_center">
                    <div class="container">
                        <div class="row">
                            <!-- 30% Column -->
                            <div class="col-md-6">
                                <h6 class="fw-bold">Welcome to</h6>
                                <h1 class="text-uppercase">Jogindra Convent School</h1>
                                <div class="border border-dark  w-25"></div>
                                <p class=" text text-justify bg-light">
                                    JCS prepares students to understand, contribute to, and succeed in a rapidly
                                    changing society, thus making the world a better and more just place. We will ensure
                                    that our students develop both the skills that a sound education provides and the
                                    competencies essential for success and leadership in the emerging creative economy.
                                    We will also lead in generating practical and theoretical knowledge that enables
                                    people to better understand our world and improve conditions for local and global
                                    communities.</p>
                            </div>
                            <div class="col-md-6">
                                <img src="img/values-01.jpg" class="img-fluid rounded img-thumbnail img1"
                                    alt="School Building">
                            </div>

                            <!-- 70% Column -->
                        </div>
                </section>
                <div class="container">
                    <h1 class="text-center">Our Values</h1>



                    <ul class="daljit">
                        <li><i class="fa fa-arrow-right" aria-hidden="true"></i><b> Learning –</b> Supporting a learning
                            environment that continuously</li>
                        <li><i class="fa fa-arrow-right" aria-hidden="true"></i><b> Relationships –</b> Creating and
                            maintaining meaningful
                            relationships among students, families, teachers, staff, and community partners</li>
                        <li><i class="fa fa-arrow-right" aria-hidden="true"></i><b> Integrity –</b> Conducting ourselves
                            with honesty and
                            responsibility</li>
                        <li><i class="fa fa-arrow-right" aria-hidden="true"></i><b> Accountability –</b> Demonstrating a
                            personal and institutional accountability for student learning, ethical conduct, and
                            adherence to mandates, &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;policies, and
                            procedures</li>
                        <li><i class="fa fa-arrow-right" aria-hidden="true"></i><b> Respect –</b> Promoting a school
                            community that appreciates the value of students, families, colleagues, and cultures</li>
                        <li><i class="fa fa-arrow-right" aria-hidden="true"></i><b> Service –</b> Dedicating ourselves
                            to delivering excellent service</li>
                    </ul>

                </div>
            </div>
        </div>
    </div>
</body>

</html>