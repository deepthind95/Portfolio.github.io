<?php

include 'top_links.php';
include 'includes/db.php';
$query = "SELECT * FROM students WHERE designation = 'Sports Girl Of the Year' ORDER BY id ASC LIMIT 10";
$result = mysqli_query($conn, $query);
$dir = "uploads/"

?>
<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


  
    <title>Jogindra Convent School</title>
  </head>




  <div class="container my-3">
  <div class="row">
    <div class="col-md-2">
    <?php include 'sidebar.php';
?>
</div>
<div class="col-md-10">
<h1 class="bg-primary text-white text-center"><i class="fas fa-running text-white mx-2 "></i> Sports Girl Of The Year</h1>  
   <table id="studentTable" class="table text-center table-bordered table-info ">
      <thead>
        <tr class="table-dark">
        <th>#</th>
        <th>Photo</th>
        <th>Student Name</th>
        <th>Designation</th>
        <th>Session</th>
      </tr>
    </thead>
    <tbody>
      <?php if (mysqli_num_rows($result) > 0): ?>
        <?php $id = 0; ?>
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
          <?php $id++; ?>
          <tr>
            <td><?= $id; ?></td>
            <td>
              <img src="<?= htmlspecialchars("admin/".$row['student_photo']); ?>" class="img-fluid img-thumbnail rounded-circle" width="80"
                alt="Student Photo">
            </td>
            <td><?= htmlspecialchars($row['student_name']); ?></td>
            <td><?= htmlspecialchars($row['designation']); ?></td>
            <td><?= htmlspecialchars($row['session']); ?></td>
  
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr>
          <td colspan="6" class="text-center">No records found.</td>
        </tr>
      <?php endif; ?>
    </tbody>
  
  </table>
  </div>

  </div>

</div>
