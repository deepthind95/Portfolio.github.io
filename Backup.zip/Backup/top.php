<!-- Top Bar -->
<div class="container-fluid bg-white border-bottom py-2">
    <div class="row align-items-center text-center text-md-start g-2">

        <!-- Contact Info -->
        <div class="col-12 col-md-4 d-flex flex-wrap justify-content-center justify-content-md-start align-items-center gap-3 small text-dark">
            <div class="d-flex align-items-center">
                <i class="fas fa-envelope me-2 text-warning"></i>
                <a href="mailto:info@jogindraconventschool.com" class="text-decoration-none text-dark">info@jogindraconventschool.com</a>
            </div>
            <div class="d-flex align-items-center">
                <i class="fas fa-phone me-2 text-warning"></i>
                <a href="tel:+919478850505" class="text-decoration-none text-dark">+91 94788 50505</a>
            </div>
        </div>

        <!-- Login & Map Buttons -->
        <div class="col-12 col-md-4 d-flex justify-content-center align-items-center flex-wrap gap-2">
            <a href="https://jcsfzr.schoolpad.in/loginManager/load" target="_blank" class="btn btn-sm btn-outline-primary shadow-sm" aria-label="Student Login">
                <i class="fas fa-user-circle me-1"></i> Student / Parent Login
            </a>
            <a href="https://maps.app.goo.gl/oDUHTP2JKJECTBzk7" target="_blank" class="btn btn-sm btn-outline-success shadow-sm" aria-label="Location Map">
                <i class="fas fa-map-marker-alt me-1"></i> Location Map
            </a>
        </div>

        <!-- Registration & Social Links -->
        <div class="col-12 col-md-4 d-flex justify-content-center justify-content-md-end align-items-center gap-3 flex-wrap">
            <a href="https://jcsfzr.schoolpad.in/enquiryManager/onlineAdmission/11" target="_blank" class="btn btn-sm btn-dark rounded-pill px-3 py-1 text-white" aria-label="Online Registration">
                <i class="fas fa-sign-in-alt me-1"></i> Online Registration 2025-26
            </a>
            <div class="d-flex align-items-center gap-2 flex-wrap">
                <a href="https://www.facebook.com/jcs.fzr/" class="text-primary fs-5" aria-label="Facebook"><img src="img/social_media/facebook.jpeg" width="30"></a>
                <a href="https://x.com/i/flow/login?redirect_after_login=%2FJogindraSchool" class="text-info fs-5" aria-label="Twitter"><img src="img/social_media/twitter.jpeg" width="30"></a>
                <a href="https://www.youtube.com/channel/UCm8_5OAR1oAjFa_kvREEe_Q" class="text-danger fs-5" aria-label="YouTube"><img src="img/social_media/youtube.jpeg" width="30"></a>
                <a href="https://www.instagram.com/jcsfzr/" class="text-danger fs-5" aria-label="Instagram"><img src="img/social_media/insta.jpeg" width="30"></a>
                <a href="https://www.linkedin.com/company/jogindra-convent-school-ferozepur/" class="text-primary fs-5" aria-label="LinkedIn"><img src="img/social_media/linkedin.jpeg" width="30"></a>
                <a href="https://wa.me/919478850505" class="text-success fs-5" aria-label="WhatsApp"><img src="img/social_media/whatsapp.jpeg" width="30"></a>
            </div>
        </div>

    </div>
</div>

<!-- Main Header -->
<div class="container-fluid py-3 bg-white shadow-sm border-bottom">
    <div class="container">
        <div class="row align-items-center g-3">
            <div class="col-12 d-flex flex-column flex-lg-row align-items-center justify-content-between gap-3 text-center text-lg-start">

                <!-- Logo -->
                <div class="flex-shrink-0">
                    <img src="img/logo1.png" alt="Jogindra Convent School Logo" class="img-fluid" style="max-height: 90px;">
                </div>

                <!-- School Info -->
                <div class="d-flex flex-column flex-lg-row align-items-center gap-4 flex-wrap justify-content-center text-nowrap">
                    <h5 class="text-warning fw-bold mb-0">Jogindra Convent School</h5>
                    <h6 class="text-info fw-semibold mb-0">Affiliation: ICSE & ISC School</h6>
                    <h6 class="text-primary fw-normal mb-0">Commerce · Humanities · Science</h6>
                    <h6 class="text-muted d-flex align-items-center mb-0">
                        <i class="fas fa-clock me-2 text-warning"></i> School Timings: 9:00 AM - 2:20 PM
                    </h6>
                </div>

            </div>
        </div>
    </div>
</div>