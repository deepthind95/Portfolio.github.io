<?php
include 'top.php';
include 'links.php';
?>
<div class="container-fluid mt-1 image1">
  <div class="position-relative">
    <div class="carousel-overlay position-absolute  start-0 w-100 h-100 bg-dark opacity-50"></div>
    <img src="img/slider-01.jpg" class="image" alt="">
    <div class="carousel-caption text-end position-absolute top-50 start-50 translate-middle text-light">

      <h2 class="fw-bold text-uppercase">Admission open 2025-26</h2>




    </div>
    </div>
    <div class="container">

<div class="row my-2">
<div class="col-sm-12">
<img src="img/add-mission.jpg" class="w-25 mx-auto d-block img-thumbnail" alt="">
</div>
</div>
</div>
    <?php include 'footer.php'; ?>

  