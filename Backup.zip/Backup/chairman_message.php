<?php include 'top_links.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container-fluid">
<div class="row">
<div class="col-sm-2">
<?php include 'sidebar.php';?>
</div>
<div class="col-sm-10">
<section class="py-5 section-container">
        <div class="container-fluid">
<h1 class="text-center text-bg-primary my-3">Chairman Message </h1>


            <div class="row">
                <div class="col-md-4">
                    <img src="img/hnji.jpg" class="img-fluid  img-thumbnail w-100 img2" alt="School Building">
                </div>
                <div class="col-md-8">

                    <h1 class="text-uppercase">From Chairman's Desk</h1>
                    <div class="border border-dark  w-25 my-1"></div>
                    <p class=" text-break text-justify  bg-light text">Jogindra Convent School, Jogindergarh (Ferozepur)
                        established in 2009 under the aegis of the Sardar Joginder Singh Charitable Trust, is committed
                        to prepare global citizens equipped with the life skills required to meet the constantly
                        changing challenges and needs of the world around them. As part of a society that stands for
                        educational leadership, scholarly achievement and a progressive approach, we combine the tenets
                        of a traditional value based system with global trends and a world class infrastructure.
                        Education, for us, is not a destination but a journey of discovery, of exploration, of
                        introspection, of interrogation,...</p>
                    <h4 class="  p-2 w-50 my-2">Hardeep Singh</h4>
                    <h5 class="bg-light text-dark p-2 w-50 my-2">M.A, LLB.</h5>



                </div>
            </div>
        </div>
    </section>
</div>
</div>
    </div>
</body>
</html>
