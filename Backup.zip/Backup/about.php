    <?php include 'top.php';
    include 'top_links.php';
    ?>
    <section class="py-5 section-container">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    <img src="img/about-service.jpg" class="img-fluid rounded img-thumbnail img1" alt="School Building">
                </div>
                <!-- 30% Column -->
                <div class="col-md-6">
                    <h6 class="fw-bold">Welcome to</h6>
                    <h1 class="text-uppercase">Jogindra Convent School</h1>
                    <div class="border border-dark  w-25"></div>
                    <p class=" text text-justify bg-light">With early education gaining new dimensions the dire need is
                        not only to succeed but to lead in this intensely competitive, technology driven and fast
                        evolving global society, JCS completes the design of this type of educational programme,
                        stretching from Kindergarten to Class Xl with all streams. School education is the foundation
                        for a student's life. Unless and until the quality of education at the school level is improved,
                        it is futile to expect quality in higher education. Set in a calm, safe, pristine, pollution
                        free, eco-friendly environment, JCS has truly been a milestone for this rural area as it
                        provides global learning experience to its students and nourishes them to be responsible
                        citizens....</p>
                </div>
    
                <!-- 70% Column -->
            </div>
    </section>
    <section class="py-5 section-container bg-light ">
        <div class="container-fluid">
            <div class="row  py-2">
                <!-- 30% Column -->
                <div class="col-md-6">
    
                    <h1 class="text-uppercase">Our Mission</h1>
                    <div class="border border-dark  w-25"></div>
                    <p class=" text text-justify bg-light">Our mission is to make sure we are able to alleviate the moving
                        stress off of the customer by providing top quality service without burning a hole in their pocket.
                        We try to touch hearts with our craft, dedication and congeniality.</p>
                    <div class="my-3"></div>
    
    
                    <p class=" text text-justify bg-light">We want to help you get moving! If you are relocating your home
                        or business within Ontario, you’ll want the reliable professionals at Jogindra Convent School. Our
                        commitment to helping our customers extends beyond just moving stuff from house to house. We want
                        our customers to feel confident in our communication and services.</p>
                </div>
                <div class="col-md-6">
                    <img src="img/our-mission.png" class="img-fluid rounded border border-1 border-dark img1"
                        alt="School Building">
                </div>
    
                <!-- 70% Column -->
            </div>
    </section>
    <section class="py-5 section-container bg-light ">
        <div class="container">
            <h1 class="text-uppercase text-center">Our values</h1>
            <div class="container text-center">
                <div class="row">
                    <div class="col-lg-3 col-md-4 col-sm-12">
                        <div class="card" style="width: 18rem;">
                            <img src="img/customer-first.png" class="card-img-top w-50 mx-auto d-block" alt="...">
                            <div class="card-body">
    
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-12">
                        <div class="card" style="width: 18rem;">
                            <img src="img/Passion.png" class="card-img-top card-img-top w-50 mx-auto d-block" alt="...">
                            <div class="card-body">
    
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-12">
                        <div class="card" style="width: 18rem;">
                            <img src="img/Integrity.png" class="card-img-top card-img-top w-50 mx-auto d-block" alt="...">
                            <div class="card-body">
    
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-12">
                        <div class="card" style="width: 18rem;">
                            <img src="img/Excellence.png" class="card-img-top card-img-top w-50 mx-auto d-block" alt="...">
                            <div class="card-body">
    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    
    
    
        </div>
    </section>
    
    <section class="py-5 section-container bg-info ">
    
        <div class="container text-center">
            <div class="row">
                <h1>Ready to get moved?</h1>
                <div class="col-lg-3">
                    <img src="img/home1/parcel.png" class="img-fluid shadow-lg border-5 border border-dark" alt="...">
                </div>
    
                <div class="col-lg-8 my-5">
                    <hr class="w-25 ">
                    <h2>We will take care of everything that’s needed to be done in a move</h2>
                    <button class="w-25 btn btn-success fs-5">Get a Quote</button>
                    <button class="w-25 btn btn-danger fs-5">(437)775 -4755</button>
                </div>
            </div>
    
        </div>
        </div>
        </div>
    
    
    
    
    </section>
   