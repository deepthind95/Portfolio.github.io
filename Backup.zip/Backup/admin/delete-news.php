<?php
include 'includes/db.php';

$id = $_GET['id'];

// Get current photo name to delete the file
$result = $conn->query("SELECT image FROM news WHERE id=$id");
$row = $result->fetch_assoc();
$photo = $row['image'];

// Delete photo file
if ($photo && file_exists("uploads/$photo")) {
    unlink("uploads/news/$photo");
}

// Delete from DB
$conn->query("DELETE FROM news WHERE id=$id");

echo "<script>alert('News deleted successfully'); window.location='dashboard.php';</script>";
?>