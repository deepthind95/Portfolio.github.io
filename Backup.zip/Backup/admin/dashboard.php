<?php
session_start();
include'top.php';
include 'links.php';
include 'sidebar.php';


include 'includes/db.php'; // DB connection
if (!isset($_SESSION['username']) || !isset($_SESSION['role'])) {
    echo "<script>window.location.href = 'index.php';</script>";
    exit;
}
$username = $_SESSION['username'];
$role = ucfirst($_SESSION['role']);


// Reusable function to count students by designation
function countByDesignation($conn, $designation)
{
    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM students WHERE designation = ?");
    $stmt->bind_param("s", $designation);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();
    return $data['total'] ?? 0;
}

// Get all counts
$student_count = countByDesignation($conn, 'STUDENT OF THE YEAR');
$isc_count = countByDesignation($conn, 'ISC TOPPER');
$icse_count = countByDesignation($conn, 'ICSE TOPPER');
$school_captain_count = countByDesignation($conn, 'school captain');
$sports_boy_count = countByDesignation($conn, 'sports boy of the year');
$sports_girl_count = countByDesignation($conn, 'sports girl of the year');
$sports_boy_emerge_count = countByDesignation($conn, 'Emerging sports Boy of the year');
$sports_girl_emerge_count = countByDesignation($conn, 'Emerging sports Girl of the year');

    

?>
<!DOCTYPE html>
<html>

<head>
    <title>Dashboard | Admin Panel</title>

</head>

<body>

    <!-- Main Content -->
    <div class="container mt-4">
        <!-- Student Of the Year Card -->
        <div class="row">
            <div class="col-md-4">
                <div class="card shadow-sm border-5 bg-info">
                    <div class="card-body d-flex align-items-center">
                        <a href="student-of-the-year.php" class="text-white text-decoration-none">
                            <div class="me-3 text-primary fs-1">
                                <i class="fas fa-user-graduate"></i> <!-- Icon for Student of the Year -->
                            </div>
                            <div>
                                <h6 class="card-title mt-3 mb-1 mt-3">Student Of The Year</h6>
                                <!-- Title of the category -->
                                <h4 class="card-text fw-bold"><?= $student_count ?></h4>
                                <!-- Dynamic count of students -->
                            </div>
                    </div>
                    </a>
                </div>
            </div>
            <!-- ISC Topper Card -->
            <div class="col-md-4">
                <div class="card shadow-sm border-5 bg-success">
                    <div class="card-body d-flex align-items-center">
                        <a href="isc_topper.php" class="text-white text-decoration-none">
                            <div class="me-3 text-success fs-1">
                                <i class="fas fa-award text-white"></i> <!-- Icon for ISC Topper -->
                            </div>
                            <div>
                                <h6 class="card-title mt-3 mb-1 mt-3">ISC Topper</h6> <!-- Title of the category -->
                                <h4 class="card-text fw-bold"><?= $isc_count ?></h4>
                                <!-- Dynamic count of ISC toppers -->
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <!-- ICSE Topper Card -->
            <div class="col-md-4">
                <div class="card shadow-sm border-5 bg-danger">
                    <div class="card-body d-flex align-items-center">
                        <a href="Icse_topper.php" class="text-white text-decoration-none">
                            <div class="me-3 text-warning fs-1">
                                <i class="fas fa-trophy"></i> <!-- Icon for ICSE Topper -->
                            </div>
                            <div>
                                <h6 class="card-title mt-3 mb-1 mt-3">ICSE Topper</h6> <!-- Title of the category -->
                                <h4 class="card-text fw-bold"><?= $icse_count ?></h4>
                                <!-- Dynamic count of ICSE toppers -->
                            </div>
                        </a>
                    </div>
                </div>
            </div>

        </div>
        <!-- School Captain Card -->
        <div class="row my-3">
            <div class="col-md-4">
                <div class="card shadow-sm border-5 bg-secondary">
                    <div class="card-body d-flex align-items-center">
                        <a href="school_captain.php" class="text-white text-decoration-none">
                            <div class="me-3 text-info fs-1">
                                <i class="fas fa-chess-king"></i> <!-- Icon for School Captain -->
                            </div>
                            <div>
                                <h6 class="card-title mt-3 mb-1 ">School Captain</h6> <!-- Title of the category -->
                                <h4 class="card-text fw-bold"><?= $school_captain_count ?></h4>
                                <!-- Dynamic count of School Captains -->
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <!-- Sports Boy of the Year Card -->
            <div class="col-md-4">
                <div class="card shadow-sm border-5 bg-warning">
                    <div class="card-body d-flex align-items-center">
                        <a href="Sports_Boy.php" class="text-danger text-decoration-none">
                            <div class="me-3 text-danger fs-1">
                                <i class="fas fa-futbol"></i> <!-- Icon for Sports Boy -->
                            </div>
                            <div>
                                <h6 class="card-title mt-3 mb-1">Sports Boy Of The Year</h6>
                                <!-- Title of the category -->
                                <h4 class="card-text fw-bold"><?= $sports_boy_count ?></h4>
                                <!-- Dynamic count of Sports Boys -->
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <!-- Sports Girl of the Year Card -->
            <div class="col-md-4">
                <div class="card shadow-sm border-5 bg-primary">
                    <div class="card-body d-flex align-items-center">
                        <a href="Sports_Girl.php" class="text-white text-decoration-none">
                            <div class="me-3 text-pink fs-1">
                                <i class="fas fa-running"></i> <!-- Icon for Sports Girl -->
                            </div>
                            <div>
                                <h6 class="card-title mt-3 mb-1">Sports Girl Of The Year</h6>
                                <!-- Title of the category -->
                                <h4 class="card-text fw-bold"><?= $sports_girl_count ?></h4>
                                <!-- Dynamic count of Sports Girls -->
                            </div>
                        </a>
                    </div>
                </div>
            </div>

        </div>
        <div class="row">
            <!-- Emerging Sports Boy Card -->
            <div class="col-md-4">
                <div class="card shadow-sm border-5 bg-success">
                    <div class="card-body d-flex align-items-center">
                        <a href="Emerging_boy.php" class="text-white text-decoration-none">
                            <div class="me-3 text-white fs-1">
                                <i class="fas fa-star"></i> <!-- Icon for Emerging Sports Boy -->
                            </div>
                            <div>
                                <h6 class="card-title mb-1 mt-3">Emerging Sports Boy</h6> <!-- Title of the category -->
                                <h4 class="card-text fw-bold"><?= $sports_boy_emerge_count ?></h4>
                                <!-- Dynamic count of Emerging Sports Boys -->
                            </div>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Emerging Sports Girl Card -->
            <div class="col-md-4">
                <div class="card shadow-sm border-5 bg-danger">
                    <div class="card-body d-flex align-items-center">
                        <a href="Emerging_Girl.php" class="text-white text-decoration-none">
                            <div class="me-3 text-white fs-1">
                                <i class="fas fa-star-half-alt"></i> <!-- Icon for Emerging Sports Girl -->
                            </div>
                            <div>
                                <h6 class="card-title mb-1 mt-3">Emerging Sports Girl</h6>
                                <!-- Title of the category -->
                                <h4 class="card-text fw-bold"><?= $sports_girl_emerge_count ?></h4>
                                <!-- Dynamic count of Emerging Sports Girls -->
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

    </div>
</body>
</html>
<?php include 'footer.php'; ?>