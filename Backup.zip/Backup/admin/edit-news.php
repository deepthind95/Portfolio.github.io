<?php
include('includes/db.php');
include 'links.php';
session_start();
include 'sidebar.php';

// Get news by ID
if (!isset($_GET['id'])) {
    header("Location: news-list.php");
    exit();
}

$id = intval($_GET['id']);
$query = "SELECT * FROM news WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$news = $result->fetch_assoc();

if (!$news) {
    echo "News not found.";
    exit();
}

// Handle form submission
if (isset($_POST['submit'])) {
    $title = $conn->real_escape_string($_POST['title']);
    $description = $conn->real_escape_string($_POST['description']);
    $link = $conn->real_escape_string($_POST['link']);
    
    $imagePath = $news['image'];
    $pdfPath = $news['file'];

    if (!empty($_FILES['file']['name'])) {
        $fileName = $_FILES['file']['name'];
        $fileTmp = $_FILES['file']['tmp_name'];
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $uploadDir = '';
        $targetFile = '';

        if (in_array($fileExt, ['jpg', 'jpeg', 'png', 'gif'])) {
            $uploadDir = 'uploads/';
            $imagePath = $uploadDir . uniqid() . '_' . $fileName;
            move_uploaded_file($fileTmp, $imagePath);
            $pdfPath = ''; // clear PDF if image uploaded
        } elseif ($fileExt === 'pdf') {
            $uploadDir = 'news/';
            $pdfPath = $uploadDir . uniqid() . '_' . $fileName;
            move_uploaded_file($fileTmp, $pdfPath);
            $imagePath = ''; // clear image if PDF uploaded
        }
    }

    // Update the record with link
    $stmt = $conn->prepare("UPDATE news SET title=?, description=?, link=?, image=?, file=? WHERE id=?");
    $stmt->bind_param("sssssi", $title, $description, $link, $imagePath, $pdfPath, $id);
    $stmt->execute();

    echo "<script>window.location.href = 'news_list.php';</script>";
    exit();
}
?>

<!-- HTML Form Starts -->
<form action="edit-news.php?id=<?= $news['id'] ?>" method="POST" enctype="multipart/form-data">
    <div class="container my-5">
        <div class="card shadow border-0">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">Edit News</h4>
            </div>
            <div class="card-body">
                <!-- Title -->
                <div class="mb-3">
                    <label class="form-label">News Title</label>
                    <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($news['title']) ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">News Link</label>
                    <input type="url" name="link" class="form-control" value="<?= htmlspecialchars($news['link']) ?>">
                </div>

                <!-- Description -->
                <div class="mb-3">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="4" required><?= htmlspecialchars($news['description']) ?></textarea>
                </div>

                <!-- Current Preview -->
                <div class="mb-3">
                    <label class="form-label">Current Media</label><br>
                    <?php if (!empty($news['image'])): ?>
                        <img src="<?= $news['image'] ?>" class="img-thumbnail" width="120" id="currentImage">
                    <?php elseif (!empty($news['file'])): ?>
                        <a href="<?= $news['file'] ?>" target="_blank" class="btn btn-outline-info btn-sm">View Current PDF</a>
                    <?php else: ?>
                        <p class="text-muted">No file uploaded.</p>
                    <?php endif; ?>
                </div>

                <!-- File Upload -->
                <div class="mb-3">
                    <label class="form-label">Upload New Image or PDF (optional)</label>
                    <input type="file" name="file" class="form-control" id="fileInput" accept=".jpg,.jpeg,.png,.gif,.pdf" onchange="previewFile(this);">
                </div>

                <!-- Preview Area -->
                <div id="previewArea" class="mb-4" style="display:none;">
                    <label class="form-label">Preview of New Upload</label><br>
                    <img id="imagePreview" class="img-thumbnail mb-2" width="120" style="display:none;">
                    <p id="pdfPreview" class="text-info" style="display:none;">PDF selected: <span id="pdfFileName"></span></p>
                </div>

                <!-- Submit -->
                <button type="submit" name="submit" class="btn btn-primary">Update News</button>
            </div>
        </div>
    </div>
</form>

<!-- JS Preview Script -->
<script>
function previewFile(input) {
    const file = input.files[0];
    if (!file) return;

    const previewArea = document.getElementById('previewArea');
    const imagePreview = document.getElementById('imagePreview');
    const pdfPreview = document.getElementById('pdfPreview');
    const pdfFileName = document.getElementById('pdfFileName');

    const ext = file.name.split('.').pop().toLowerCase();
    previewArea.style.display = 'block';

    if (['jpg', 'jpeg', 'png', 'gif'].includes(ext)) {
        const reader = new FileReader();
        reader.onload = function(e) {
            imagePreview.src = e.target.result;
            imagePreview.style.display = 'block';
            pdfPreview.style.display = 'none';
        };
        reader.readAsDataURL(file);
    } else if (ext === 'pdf') {
        imagePreview.style.display = 'none';
        pdfPreview.style.display = 'block';
        pdfFileName.textContent = file.name;
    } else {
        alert("Invalid file type selected.");
        input.value = '';
        previewArea.style.display = 'none';
    }
}
</script>
