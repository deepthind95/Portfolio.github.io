<?php
// Include external links and stylesheets
include 'links.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jogindra Convent School</title>
    <!-- Additional head content can be added here -->
</head>
<body>
<!-- Top Bar: Displays contact info and social media links -->
<div class="top-bar py-2 bg-light text-dark border-bottom">
    <div class="container">
        <div class="row align-items-center">
            <!-- Contact Info Section -->
            <div class="col-md-6 d-flex align-items-center small">
                <i class="fas fa-envelope me-2 text-primary"></i>
                <span class="me-3">info@jcsfzr.com</span>
                <i class="fas fa-phone me-2 text-primary"></i>
                <span>+91 94789-50505</span>
            </div>

            <!-- Registration Button & Social Icons Section -->
            <div class="col-md-6 d-flex justify-content-end align-items-center">
                <!-- Online Registration Button -->
                <a href="https://jcsfzr.schoolpad.in/enquiryManager/onlineAdmission/11" target="_blank" class="btn btn-sm btn-info text-white me-3 animate__animated animate__pulse animate__infinite">
                    Online Registration 2025–26
                </a>
                <!-- Social Media Icons -->
                <div class="social-icons d-flex align-items-center">
                    <a href="https://www.facebook.com/jcs.fzr/" target="_blank" class="text-dark fs-5 me-2 social-hover"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://x.com/i/flow/login?redirect_after_login=%2FJogindraSchool" target="_blank" class="text-dark fs-5 me-2 social-hover"><i class="fab fa-twitter"></i></a>
                    <a href="https://www.youtube.com/channel/UCm8_5OAR1oAjFa_kvREEe_Q" target="_blank" class="text-dark fs-5 me-2 social-hover"><i class="fab fa-youtube"></i></a>
                    <a href="https://www.instagram.com/jcsfzr/" target="_blank" class="text-dark fs-5 me-2 social-hover"><i class="fab fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/company/jogindra-convent-school-ferozepur/" target="_blank" class="text-dark fs-5 social-hover"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Sticky Header: Contains logo and quick access buttons -->
<div class="container-fluid bg-white shadow-sm sticky-top py-3 main-header">
    <div class="container">
        <div class="row align-items-center justify-content-between">
            <!-- Logo Section -->
            <div class="col-md-7">
                <a href="/">
                    <div class="text-center mx-auto header1">
                        <img src="img/logo.png" alt="Jogindra Convent School Logo" class="img-fluid" style="max-height: 600px;">
                    </div>
                </a>
            </div>

            <!-- Login & Location Buttons Section -->
            <div class="col-md-5">
                <div class="d-flex flex-wrap justify-content-md-end justify-content-center gap-2">
                    <!-- Student/Parent Login Button -->
                    <a href="https://jcsfzr.schoolpad.in/loginManager/load" target="_blank" class="btn btn-sm btn-outline-primary shadow-sm">
                        <i class="fas fa-user-circle me-1"></i> Student/Parent Login
                    </a>
                    <!-- Location Map Button -->
                    <a href="https://maps.app.goo.gl/oDUHTP2JKJECTBzk7" target="_blank" class="btn btn-sm btn-outline-success shadow-sm">
                        <i class="fas fa-map-marker-alt me-1"></i> Location Map
                    </a>
                </div>
            </div>
            <!-- Navigation Bar can be added here if needed -->
        </div>
    </div>
</div>

<!-- Floating Buttons (Commented Out): For quick call and WhatsApp chat -->
<!-- 
<a href="tel:+919478850505" class="btn-floating phone text-decoration-none d-flex align-items-center" title="Call Now">
    <i class="fas fa-phone animate__animated animate__bounce"></i>
    <span class="ms-2">Call Us</span>
</a>

<a href="https://wa.me/919478850505" target="_blank" class="btn-floating whatsapp text-decoration-none d-flex align-items-center" title="Chat on WhatsApp">
    <i class="fab fa-whatsapp animate__animated animate__bounce"></i>
    <span class="ms-2">Chat Now</span>
</a> 
-->
