<?php include 'top.php';
include 'includes/db.php';

include 'sidebar.php';
$id = $_GET['id'];
$result = $conn->query("SELECT * FROM students WHERE id=$id");
$row = $result->fetch_assoc();

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  

  <title>Jogindra Convent School</title>



</head>
<div class="container-fluid mt-1 image1">
  <div class="position-relative">
    <div class="carousel-overlay position-absolute  start-0 w-100 h-100 bg-dark opacity-50"></div>
    <img src="img/slider-01.jpg" class="image" alt="">
    <div class="carousel-caption text-end position-absolute top-50 start-50 translate-middle text-light">

      <h2 class="fw-bold text-uppercase">Emerging Sports Girl Of The Year</h2>
</div>
  </div>
  
  <div class="container">
  <h1 class="my-3 text-center">Edit Form</h1>
  <form action="update_student.php" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?= $row['id'] ?>">
    
    <div class="mb-3">
      <label class="form-label">Student Name</label>
      <input type="text" name="student_name" class="form-control" value="<?= $row['student_name'] ?>" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Session</label>
      <input type="text" name="session" class="form-control" value="<?= $row['session'] ?>" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Designation</label>
      <input type="text" name="designation" class="form-control" value="<?= $row['designation'] ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Current Photo</label><br>
        <?php $photoPath = '' . $row['student_photo']; ?>
        <?php if (!empty($row['student_photo']) && file_exists($photoPath)): ?>
          <img src="<?= htmlspecialchars($photoPath) ?>" alt="Student Photo" width="100" class="img-thumbnail mb-2" id="currentPhoto">
        <?php else: ?>
          <div class="text-muted mb-2">No photo available</div>
        <?php endif; ?>

        <input type="file" name="student_photo" class="form-control" accept="image/*" onchange="previewPhoto(this)">
        <small class="form-text text-muted">Allowed formats: JPG, PNG, JPEG. Max size: 2MB</small>

        <div class="mt-2" id="previewArea" style="display: none;">
          <label class="form-label">New Photo Preview:</label><br>
          <img id="photoPreview" src="#" alt="New Photo" width="100" class="img-thumbnail">
        </div>
      </div>

    <button type="submit" class="btn btn-primary">Update</button>
  </form>

  </div>
  <script>
  function previewPhoto(input) {
    if (input.files && input.files[0]) {
      const reader = new FileReader();

      reader.onload = function(e) {
        document.getElementById('previewArea').style.display = 'block';
        document.getElementById('photoPreview').src = e.target.result;
      };

      reader.readAsDataURL(input.files[0]);
    }
  }
</script>
