<?php
session_start();
include('includes/db.php');
include 'links.php';
include 'sidebar.php';

// Handle form submission
if (isset($_POST['submit'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $link = $_POST['link'] ?? '';
    $image = '';
    $file = '';

    // File upload logic
    if (!empty($_FILES['file']['name'])) {
        $fileTmp = $_FILES['file']['tmp_name'];
        $originalName = basename($_FILES['file']['name']);
        $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
        $uniqueName = time() . '_' . preg_replace("/[^a-zA-Z0-9.]/", "_", $originalName);

        if (in_array($extension, ['jpg', 'jpeg', 'png', 'gif'])) {
            $image = 'uploads/' . $uniqueName;
            move_uploaded_file($fileTmp, $image);
        } elseif ($extension === 'pdf') {
            $file = 'news/' . $uniqueName;
            move_uploaded_file($fileTmp, $file);
        } else {
            echo "<script>alert('Unsupported file type. Only JPG, PNG, GIF, and PDF are allowed.');</script>";
            exit;
        }
    }

    // Insert into database (Make sure your DB table has a `link` column)
    $stmt = $conn->prepare("INSERT INTO news (title, description, link, image, file) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $title, $description, $link, $image, $file);
    $stmt->execute();

    echo "
    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
    <script>
        Swal.fire({
            title: 'Success!',
            text: 'News added successfully.',
            icon: 'success',
            confirmButtonText: 'OK'
        }).then(() => {
            window.location.href = 'news_list.php';
        });
    </script>";
}

?>

<!-- HTML Form UI -->
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow border-0">
                <div class="card-header bg-success text-white">
                    <h4 class="mb-0">Add News</h4>
                </div>
                <div class="card-body p-4">
                    <form action="add-news.php" method="POST" enctype="multipart/form-data">
                        <!-- Title -->
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Title</label>
                            <input type="text" name="title" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Link</label>
                            <input type="url" name="link" class="form-control">
                        </div>

                        <!-- Description -->
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Description</label>
                            <textarea name="description" class="form-control" rows="4" required></textarea>
                        </div>

                        <!-- File Upload -->
                        <div class="mb-3">
                            <label for="newsFile" class="form-label fw-semibold">Upload Image or PDF</label>
                            <input type="file" name="file" id="newsFile" class="form-control" accept=".jpg,.jpeg,.png,.gif,.file" required>
                            <div class="form-text">Accepted formats: JPG, PNG, GIF, PDF</div>
                        </div>

                        <!-- Submit Button -->
                        <div class="d-grid">
                            <button type="submit" name="submit" class="btn btn-success">Add News</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Optional: JavaScript File Type Validation -->
<script>
document.getElementById('newsFile').addEventListener('change', function () {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf'];
    const file = this.files[0];
    if (file && !allowedTypes.includes(file.type)) {
        alert('Invalid file type. Please upload an image or PDF.');
        this.value = '';
    }
});
</script>
