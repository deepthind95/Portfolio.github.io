<?php include 'top_links.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container-fluid">
<div class="row">
<div class="col-sm-2">
<?php include 'sidebar.php';?>
</div>
<div class="col-sm-10">
<section class="py-5 section-container">
                    <div class="container">
                        <h1 class="text-center mb-4">Latest News</h1>

                        <div class="container py-1">
                            <div class="row">
                                <?php
                                include 'includes/db.php';
                                $news = $conn->query("SELECT * FROM news ORDER BY id DESC LIMIT 3");

                                while ($row = $news->fetch_assoc()) {
                                    $title = htmlspecialchars($row['title']);
                                    $description = substr(strip_tags($row['description']), 0, 100) . '...';
                                    $link = !empty($row['link']) ? htmlspecialchars($row['link']) : "view_news.php?id=" . $row['id'];
                                    $target = (!empty($row['link']) && str_starts_with($row['link'], 'http')) ? ' target="_blank"' : '';

                                    $imageFile = htmlspecialchars($row['image']);
                                    $pdfFile = htmlspecialchars($row['file']);

                                    $imagePath = (!empty($imageFile) && !str_ends_with(strtolower($imageFile), '.pdf')) ? 'admin/' . $imageFile : '';
                                    $pdfPath = (!empty($pdfFile) && str_ends_with(strtolower($pdfFile), '.pdf')) ? 'admin/' . $pdfFile : '';

                                    $fileExt = strtolower(pathinfo($imagePath ?: $pdfPath, PATHINFO_EXTENSION));
                                    ?>
                                    <div class="col-md-4 mb-4">
                                        <div class="card h-100 shadow-sm">
                                            <?php if (!empty($imagePath) && in_array($fileExt, ['jpg', 'jpeg', 'png', 'gif'])): ?>
                                                <img src="<?= $imagePath ?>" class="card-img-top" alt="<?= $title ?>"
                                                    style="height: 200px; object-fit: cover;">
                                            <?php elseif (!empty($pdfPath) && $fileExt === 'pdf'): ?>
                                                <img src="img/pdf.svg" class="card-img mt-3  img-fluid w-100" alt="PDF File"
                                                    style="height: 300px; object-fit: contain;">
                                            <?php endif; ?>

                                            <div class="card-body d-flex flex-column">
                                                <h5 class="card-title"><?= $title ?></h5>
                                                <p class="card-text"><?= $description ?></p>

                                                <?php if (!empty($pdfPath)): ?>
                                                    <a href="<?= $pdfPath ?>" class="btn btn-danger mt-auto" download>
                                                        <i class="fas fa-download"></i> Download PDF
                                                    </a>
                                                <?php else: ?>
                                                    <a href="<?= $link ?>" <?= $target ?> class="btn btn-primary mt-auto">
                                                        Read More
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </section>
</div>
</div>
    </div>
</body>
</html>