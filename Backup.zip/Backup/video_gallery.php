<?php include 'top_links.php'; ?>
<?php include 'top_links.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-2">
                <?php include 'sidebar.php'; ?>
            </div>
            <div class="col-sm-10">
                <h1 class="text-center my-3">Video Gallery</h1>
                <iframe class="img-thumbnail mx-3" src="https://www.youtube.com/embed/baknUjywjYU"
                    title="JCS Ferozepur School Choir (2018)" frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                <iframe class="img-thumbnail mx-3" src="https://www.youtube.com/embed/AC47wjocYEk"
                    title="JCS Boys Jhoomer" frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                <iframe class="img-thumbnail mx-3" src="https://www.youtube.com/embed/OjbtOHLfUVw"
                    title="JCS Girls&#39; beautiful dance on beautiful speech of Malala Yousafzai @jcsfzr"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                <iframe class="img-thumbnail mx-3" src="https://www.youtube.com/embed/W64SGBFnMOE"
                    title="Ludi by JCS Girls" frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                <iframe class="img-thumbnail mx-3" src="https://www.youtube.com/embed/PPQyLr8CRTQ"
                    title="JCS Drama Competition 2019-20." frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                <iframe class="img-thumbnail mx-3" src="https://www.youtube.com/embed/kKLPfkqvsi0"
                    title="JCS Annual Sports Meet 2018." frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                <iframe class="img-thumbnail mx-3" src="https://www.youtube.com/embed/ZFynmnoauaw"
                    title="Dance by little #JCSians on Annual Day 2020 held on Oct 30, 2021 @jcsfzr" frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                <iframe class="img-thumbnail mx-3" src="https://www.youtube.com/embed/f7xiHr6hazM"
                    title="Gatka by JCS Students." frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                <iframe class="img-thumbnail mx-3" src="https://www.youtube.com/embed/Q2SVH63dy38"
                    title="Indian Traditional Dance by Middle School Girls on Annual Day 2020 held on Oct 30, 2021."
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                <iframe class="img-thumbnail mx-3" src="https://www.youtube.com/embed/WIzDrzhiHus"
                    title="Mime by students of Middle School on Annual Day 2020 held on October 30, 2021."
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                </div>
                <a target="_blank"  href="https://www.youtube.com/@jcsfzr" class="btn mx-auto my-3"><img src="img/youtube-color-svgrepo-com.svg" class="img-fluid" width="70" alt=""> Click To View More Videos</a>
        </div>
</body>

</html>