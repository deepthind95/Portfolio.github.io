<?php include 'top_links.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container-fluid">
<div class="row">
<div class="col-sm-2">
<?php include 'sidebar.php';?>
</div>
<div class="col-sm-10">
<section class="py-5 section-container">
        <div class="container-fluid">
<h1 class="text-center text-bg-primary my-3">Principal Message </h1>


            <div class="row">
            <div class="col-md-8">

<h1 class="text-uppercase">From Principal's Desk</h1>
<div class="border border-dark  w-25"></div>
<p class=" text-break text-justify text bg-light">Today, the role of a school is not only to pursue
    the academic excellence but also to motivate and empower the students to be lifelong learners,
    critical thinkers, and productive members o' n ever-changing global society. Converting every
    individual into a self-reliant and independent citizen, our school provides an amalgam of
    scholastic and co-scholastic activities. The world today is changing at such an accelerated rate
    and we as educator need to pause and reflect on this entire system of Education. "To Motivate
    the Late bloomers o mould the Mediocre and To Challenge the Gifted" is the teaching notion....
</p>
<h4 class="">Simrandeep Singh Dhaliwal</h4>
<h5 class="bg-light text-dark  p-2 w-50 my-2">M.A. (English) M.Ed..</h5>



</div>
<div class="col-md-4">
                <img src="img/wdjiscji.jpg" class="img-fluid img-thumbnail w-100 img3 " alt="School Building">
            </div>
            </div>
        </div>
    </section>
</div>
</div>
    </div>
</body>
</html>
