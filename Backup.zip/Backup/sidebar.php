<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sidebar with Toggle</title>
    <?php include 'top_links.php' ?>
    <style>
        body {
            overflow-x: hidden;
        }

        #sidebar {
            width: 280px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: #f8f9fa;
            overflow-y: auto; /* Enable vertical scrolling */
            transition: all 0.3s;
            z-index: 998;
        }

        #sidebar.collapsed {
            margin-left: -280px;
        }

        #content {
            margin-left: 280px;
            transition: all 0.3s;
            padding: 20px;
        }

        #content.expanded {
            margin-left: 0;
        }

        .toggle-btn {
            position: fixed;
            left: 10px;
            top: 10px;
            z-index: 999;
        }

        /* Optional: hide scrollbars in sidebar on WebKit (Chrome/Safari) */
        #sidebar::-webkit-scrollbar {
            width: 6px;
        }

        #sidebar::-webkit-scrollbar-thumb {
            background-color: rgba(0, 0, 0, 0.2);
            border-radius: 4px;
        }
    </style>
</head>
<body>

<!-- Toggle Button -->
<button class="btn btn-primary toggle-btn" id="toggleBtn">☰</button>

<!-- Sidebar Start -->
<div id="sidebar" class="d-flex flex-column p-3 bg-light text-dark">
    <a href="index.php" class="text-center display-4 text-dark text-decoration-none">
        Menu
    </a>
    <hr>
    <ul class="nav nav-pills flex-column mb-auto">
        <li class="nav-item">
            <a href="index.php" class="nav-link active">Home</a>
        </li>

        <!-- About Us -->
        <li>
            <a class="nav-link text-dark" data-bs-toggle="collapse" href="#aboutUsMenu" role="button" aria-expanded="false" aria-controls="aboutUsMenu">
                About Us
            </a>
            <div class="collapse" id="aboutUsMenu">
                <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                    <li><a href="chairman_message.php" class="nav-link text-dark">Chairman's Message</a></li>
                    <li><a href="principal.php" class="nav-link text-dark">Principal’s Message</a></li>
                    <li><a href="vision-mission.php" class="nav-link text-dark">Vision & Mission</a></li>
                    <li><a href="aims.php" class="nav-link text-dark">Aims and Objectives</a></li>
                    <li><a href="#" class="nav-link text-dark">Important Features</a></li>
                    <li><a href="#" class="nav-link text-dark">Awards and Scholarships</a></li>
                    <li><a href="#" class="nav-link text-dark">Meet Our Team</a></li>
                </ul>
            </div>
        </li>

        <!-- School Currere -->
        <li>
            <a class="nav-link text-dark" data-bs-toggle="collapse" href="#schoolCurrere" role="button" aria-expanded="false" aria-controls="schoolCurrere">
                School Currere
            </a>
            <div class="collapse" id="schoolCurrere">
                <ul class="list-unstyled fw-normal pb-1 small">
                    <li><a href="kindergarten.html" class="nav-link text-dark">Kindergarten</a></li>
                    <li><a href="primary-school.html" class="nav-link text-dark">Primary School</a></li>
                    <li><a href="middle-school.html" class="nav-link text-dark">Middle School</a></li>
                    <li><a href="high-school.html" class="nav-link text-dark">High School (ICSE)</a></li>
                    <li><a href="sr-secondary.html" class="nav-link text-dark">Sr. Secondary (ISC)</a></li>
                </ul>
            </div>
        </li>

        <!-- Facilities -->
        <li>
            <a class="nav-link text-dark" data-bs-toggle="collapse" href="#facilitiesMenu" role="button" aria-expanded="false" aria-controls="facilitiesMenu">
                Facilities
            </a>
            <div class="collapse" id="facilitiesMenu">
                <ul class="list-unstyled fw-normal pb-1 small">
                    <li><a href="library.html" class="nav-link text-dark">Library</a></li>
                    <li><a href="laboratorium.html" class="nav-link text-dark">Laboratorium</a></li>
                    <li><a href="mathematics-laboratory.html" class="nav-link text-dark">Mathematics Laboratory</a></li>
                    <li><a href="computer-lab.html" class="nav-link text-dark">Computer Lab</a></li>
                    <li><a href="smart-class.html" class="nav-link text-dark">Smart Class</a></li>
                    <li><a href="co-curricular-activities.html" class="nav-link text-dark">Co-Curricular Activities</a></li>
                    <li><a href="transport.html" class="nav-link text-dark">Transport</a></li>
                </ul>
            </div>
        </li>

        <!-- Activities -->
        <li>
            <a class="nav-link text-dark" data-bs-toggle="collapse" href="#activitiesMenu" role="button" aria-expanded="false" aria-controls="activitiesMenu">
                Activities
            </a>
            <div class="collapse" id="activitiesMenu">
                <ul class="list-unstyled fw-normal pb-1 small">
                    <li><a href="house-system.html" class="nav-link text-dark">House System</a></li>
                    <li><a href="student-council.html" class="nav-link text-dark">Student Council</a></li>
                    <li><a href="sports.html" class="nav-link text-dark">Sports</a></li>
                    <li><a href="indoor-games.html" class="nav-link text-dark">Indoor Games</a></li>
                    <li><a href="outdoor-games.html" class="nav-link text-dark">Outdoor Games</a></li>
                    <li><a href="athletics.html" class="nav-link text-dark">Athletics</a></li>
                    <li><a href="leadership-development.html" class="nav-link text-dark">Leadership Development</a></li>
                    <li><a href="inter-house-activities.html" class="nav-link text-dark">Inter-House Activities</a></li>
                </ul>
            </div>
        </li>

        <!-- Honours Board -->
        <li>
            <a class="nav-link text-dark" data-bs-toggle="collapse" href="#honoursBoardMenu" role="button" aria-expanded="false" aria-controls="honoursBoardMenu">
                Honours Board
            </a>
            <div class="collapse" id="honoursBoardMenu">
                <ul class="list-unstyled fw-normal pb-1 small">
                    <li><a href="student-of-the-year.php" class="nav-link text-dark">Student of the Year</a></li>
                    <li><a href="Isc_topper.php" class="nav-link text-dark">ISC Topper</a></li>
                    <li><a href="Icse_Topper.php" class="nav-link text-dark">ICSE Topper</a></li>
                    <li><a href="School_captain.php" class="nav-link text-dark">School Captain</a></li>
                    <li><a href="img/Honours%20Board%20Students%20Council%20(1).pdf" class="nav-link text-dark" target="_blank">Student Council</a></li>
                    <li><a href="img/house-of-the-year-25.pdf" class="nav-link text-dark" target="_blank">House of the Year</a></li>
                    <li><a href="Sports_Boy.php" class="nav-link text-dark">Sports Boy of the Year</a></li>
                    <li><a href="Sports_Girl.php" class="nav-link text-dark">Sports Girl of the Year</a></li>
                    <li><a href="Emerging_Boy.php" class="nav-link text-dark">Emerging Sports Boy</a></li>
                    <li><a href="Emerging_Girl.php" class="nav-link text-dark">Emerging Sports Girl</a></li>
                </ul>
            </div>
        </li>

        <!-- Gallery -->
        <li>
            <a class="nav-link text-dark" data-bs-toggle="collapse" href="#galleryMenu" role="button" aria-expanded="false" aria-controls="galleryMenu">
                Gallery
            </a>
            <div class="collapse" id="galleryMenu">
                <ul class="list-unstyled fw-normal pb-1 small">
                    <li><a href="video_gallery.php" class="nav-link text-dark">Video Gallery</a></li>
                    <li><a href="photo-gallery.php" class="nav-link text-dark">Photo Gallery</a></li>
                    <li><a href="education-tour.html" class="nav-link text-dark">Education Tour</a></li>
                </ul>
            </div>
        </li>

        <!-- Notice Board -->
        <li>
            <a class="nav-link text-dark" data-bs-toggle="collapse" href="#noticeBoardMenu" role="button" aria-expanded="false" aria-controls="noticeBoardMenu">
                Notice Board
            </a>
            <div class="collapse" id="noticeBoardMenu">
                <ul class="list-unstyled fw-normal pb-1 small">
                    <li><a href="pdf/fee-structure-2025-26.pdf" class="nav-link text-dark" target="_blank">Fee Structure 2025-26</a></li>
                    <li><a href="entrance-exam-syllabus.html" class="nav-link text-dark">Entrance Exam Syllabus</a></li>
                    <li><a href="book-list.html" class="nav-link text-dark">Book List</a></li>
                    <li><a href="date-sheet.html" class="nav-link text-dark">Date Sheet</a></li>
                    <li><a href="results.html" class="nav-link text-dark">Results</a></li>
                    <li><a href="syllabus.html" class="nav-link text-dark">Syllabus</a></li>
                    <li><a href="regular-uniform.html" class="nav-link text-dark">Regular Uniform</a></li>
                    <li><a href="house-wise-uniform.html" class="nav-link text-dark">House Wise Uniform</a></li>
                    <li><a href="pdf/planner-2024-25.pdf" class="nav-link text-dark" target="_blank">Planner</a></li>
                </ul>
            </div>
        </li>

        <li class="nav-item">
            <a href="view-news.php" class="nav-link text-dark">News</a>
        </li>
    </ul>
    <hr>
</div>
<!-- Sidebar End -->



<?php include 'footer_links.php'; ?>

<!-- JavaScript for Sidebar Toggle -->
<script>
    const toggleBtn = document.getElementById('toggleBtn');
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');

    toggleBtn.addEventListener('click', () => {
        sidebar.classList.toggle('collapsed');
        content.classList.toggle('expanded');
    });
</script>

</body>
</html>