 
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jogindra Convent School</title>
    <link rel="icon" href="img/favicon/favicon-32x32.png">
</head>

<body>
    <div class="container-fluid">
        <div class="row">

            <!-- Sidebar -->
            <div class="col-lg-2 p-0">
                <?php include 'sidebar.php'; ?>
            </div>

            <!-- Main Content -->
            <div class="col-lg-10 p-4">
                <?php
                include 'top.php';
                include 'slider1.php';
                ?>
                <section class="py-5">
                    <div class="container-fluid">
                        <div class="row">
                            <!-- 30% Column -->
                            <div class="col-md-8">
                                <h6 class="fw-bold mx-5">Welcome to</h6>
                                <h1 class="text-uppercase mx-5">Jogindra Convent School</h1>
                                <div class="border border-dark  w-20"></div>
                                <p class=" text text-justify bg-light mx-5">With early education gaining new dimensions the
                                    dire need is
                                    not only to succeed but to lead in this intensely competitive, technology driven and
                                    fast
                                    evolving global society, JCS completes the design of this type of educational
                                    programme,
                                    stretching from Kindergarten to Class Xl with all streams. School education is the
                                    foundation
                                    for a student's life. Unless and until the quality of education at the school level
                                    is improved,
                                    it is futile to expect quality in higher education. Set in a calm, safe, pristine,
                                    pollution
                                    free, eco-friendly environment, JCS has truly been a milestone for this rural area
                                    as it
                                    provides global learning experience to its students and nourishes them to be
                                    responsible
                                    citizens....</p>
                                <a class="btn btn-md btn-primary  py-2 mx-5" href="about.php">Read More</a>
                            </div>

                            <!-- 70% Column -->
                            <div class="col-md-4">
                                <img src="img/about-service.jpg" class="img-fluid rounded img-thumbnail img1"
                                    alt="School Building">
                            </div>
                        </div>
                </section>
                <section class="py-5 section-container">
                    <div class="container">
                        <h1 class="text-center mb-4">Why Jogindra Convent School</h1>
                        <div class="row">
                            <!-- Column 1 -->
                            <div class="col-md-4 ">
                                <div class="card height shadow-lg">
                                    <img src="img/eyee.png" class="w-25 mx-auto d-block img-fluid zoom-effect"
                                        alt="Card 1">
                                    <div class="card-body">
                                        <h5 class="card-title text-center">Vision</h5>
                                        <p class="card-text text">We have the zeal, vision, conviction and belief to
                                            bring to one door
                                            step, what is prevailing and is progressing towards path breaking land marks
                                            of
                                            education.</p>
                                    </div>
                                </div>
                            </div>

                            <!-- Column 2 -->
                            <div class="col-md-4">
                                <div class="card height pt-2 pb-2 shadow-lg">
                                    <img src="img/bbb.png" class="w-25 mx-auto d-block img-fluid zoom-effect"
                                        alt="Card 2">
                                    <div class="card-body">
                                        <h5 class="card-title text-center">BELIEFS & VALUES</h5>
                                        <p class="card-text text fs-6">That all students should have a safe environment
                                            conducive to
                                            learning
                                            that fosters positive self-esteem, self-discipline, and responsibility. that
                                            all
                                            students have the ability to learn and that learning is a life-long
                                            process..</p>
                                    </div>
                                </div>
                            </div>

                            <!-- Column 3 -->
                            <div class="col-md-4">
                                <div class="card height shadow-lg">
                                    <img src="img/missio.png" class="w-25 img-fluid mx-auto d-block zoom-effect"
                                        alt="Card 3">
                                    <div class="card-body">
                                        <h5 class="card-title text-center">Mission</h5>
                                        <p class="card-text text">To Raise future leaders with a sense of understanding,
                                            Tolerance and
                                            empathy and to educate them to respect the cultural, linguistic and communal
                                            diversity
                                            of humanity.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="py-5 section-container">
                    <div class="container">
                        <h1 class="text-center mb-4">Latest News</h1>

                        <div class="container py-1">
                            <div class="row">
                                <?php
                                include 'includes/db.php';
                                $news = $conn->query("SELECT * FROM news ORDER BY id DESC LIMIT 3");

                                while ($row = $news->fetch_assoc()) {
                                    $title = htmlspecialchars($row['title']);
                                    $description = substr(strip_tags($row['description']), 0, 100) . '...';
                                    $link = !empty($row['link']) ? htmlspecialchars($row['link']) : "view_news.php?id=" . $row['id'];
                                    $target = (!empty($row['link']) && str_starts_with($row['link'], 'http')) ? ' target="_blank"' : '';

                                    $imageFile = htmlspecialchars($row['image']);
                                    $pdfFile = htmlspecialchars($row['file']);

                                    $imagePath = (!empty($imageFile) && !str_ends_with(strtolower($imageFile), '.pdf')) ? 'admin/' . $imageFile : '';
                                    $pdfPath = (!empty($pdfFile) && str_ends_with(strtolower($pdfFile), '.pdf')) ? 'admin/' . $pdfFile : '';

                                    $fileExt = strtolower(pathinfo($imagePath ?: $pdfPath, PATHINFO_EXTENSION));
                                    ?>
                                    <div class="col-md-4 mb-4">
                                        <div class="card h-100 shadow-sm">
                                            <?php if (!empty($imagePath) && in_array($fileExt, ['jpg', 'jpeg', 'png', 'gif'])): ?>
                                                <img src="<?= $imagePath ?>" class="card-img-top" alt="<?= $title ?>"
                                                    style="height: 200px; object-fit: cover;">
                                            <?php elseif (!empty($pdfPath) && $fileExt === 'pdf'): ?>
                                                <img src="img/pdf.svg" class="card-img mt-3  img-fluid w-100" alt="PDF File"
                                                    style="height: 300px; object-fit: contain;">
                                            <?php endif; ?>

                                            <div class="card-body d-flex flex-column">
                                                <h5 class="card-title"><?= $title ?></h5>
                                                <p class="card-text"><?= $description ?></p>

                                                <?php if (!empty($pdfPath)): ?>
                                                    <a href="<?= $pdfPath ?>" class="btn btn-danger mt-auto" download>
                                                        <i class="fas fa-download"></i> Download PDF
                                                    </a>
                                                <?php else: ?>
                                                    <a href="<?= $link ?>" <?= $target ?> class="btn btn-primary mt-auto">
                                                        Read More
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="py-5 section-container">
                    <div class="container-fluid">
                        <h1 class="text-center my-1">Learning Objectives</h1>
                        <div class="row g-4 justify-content-center">
                            <div class="col-md-4 col-lg-2">
                                <div class="card h-100">
                                    <img src="img/local-moving.jpg" class="card-img-top" alt="...">
                                    <div class="card-body text-center">
                                        <h5 class="card-title">Library</h5>
                                        <a href="#" class="btn btn-sm btn-outline-primary">Read More</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-lg-2">
                                <div class="card h-100">
                                    <img src="img/sdk.jpg" class="card-img-top" alt="...">
                                    <div class="card-body text-center">
                                        <h5 class="card-title">Laboratories</h5>
                                        <a href="#" class="btn btn-sm btn-outline-primary">Read More</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-lg-2">
                                <div class="card h-100">
                                    <img src="img/asiofjaij.jpg" class="card-img-top" alt="...">
                                    <div class="card-body text-center">
                                        <h5 class="card-title">Sports</h5>
                                        <a href="#" class="btn btn-sm btn-outline-primary">Read More</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-lg-2">
                                <div class="card h-100">
                                    <img src="img/iedviom.jpg" class="card-img-top" alt="...">
                                    <div class="card-body text-center">
                                        <h5 class="card-title">Computer Lab</h5>
                                        <a href="#" class="btn btn-sm btn-outline-primary">Read More</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-lg-2">
                                <div class="card h-100">
                                    <img src="img/fgjiodo.jpg" class="card-img-top" alt="...">
                                    <div class="card-body text-center">
                                        <h5 class="card-title">Co-Curricular Activities</h5>
                                        <a href="#" class="btn btn-sm btn-outline-primary">Read More</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-lg-2">
                                <div class="card h-100">
                                    <img src="img/eksicmsom.jpg" class="card-img-top" alt="...">
                                    <div class="card-body text-center">
                                        <h5 class="card-title">TransPort</h5>
                                        <a href="#" class="btn btn-sm btn-outline-primary">Read More</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </section>
                <section id="counter_area_main" class="py-5 ">
                    <div class="container-fluid">
                        <div class="row text-center">
                            <!-- Counter 1 -->
                            <div class="col-lg-3 col-md-6 mb-4">
                                <div class="counter_area">
                                    <div class="counters_icon mb-3">
                                        <i class="fa fa-graduation-cap  text-info" aria-hidden="true"></i>
                                    </div>
                                    <div class="counter_count">
                                        <h2 class="counter-value text-light">25</h2>
                                        <h5 class="text-light">Years of Experience</h5>
                                    </div>
                                </div>
                            </div>
                            <!-- Counter 2 -->
                            <div class="col-lg-3 col-md-6 mb-4">
                                <div class="counter_area">
                                    <div class="counters_icon mb-3">
                                        <i class="fa fa-users fa-3x text-success" aria-hidden="true"></i>
                                    </div>
                                    <div class="counter_count">
                                        <h2 class="counter-value text-light counter">900+</h2>
                                        <h5 class="text-light">Students</h5>
                                    </div>
                                </div>
                            </div>
                            <!-- Counter 3 -->
                            <div class="col-lg-3 col-md-6 mb-4">
                                <div class="counter_area">
                                    <div class="counters_icon mb-3">
                                        <i class="fas fa-chalkboard-teacher fa-3x text-warning"></i>
                                    </div>
                                    <div class="counter_count">
                                        <h2 class="counter-value text-light counter">60+</h2>
                                        <h5 class="text-light">Teachers</h5>
                                    </div>
                                </div>
                            </div>
                            <!-- Counter 4 -->
                            <div class="col-lg-3 col-md-6 mb-4">
                                <div class="counter_area">
                                    <div class="counters_icon mb-3">
                                        <i class="fa fa-bus fa-3x text-danger" aria-hidden="true"></i>
                                    </div>
                                    <div class="counter_count">
                                        <h2 class="counter-value text-light counter">19</h2>
                                        <h5 class="text-light">School Buses</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="py-5 bg-light section-container">
                    <div class="container">
                        <h2 class="text-center mb-4">Testimonials</h2>
                        <div class="row">
                            <!-- Testimonial 1 -->
                            <div class="col-md-4">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title text-center">Rajbir Kaur</h4>
                                        <div class="stars text-center">
                                            ★★★★★
                                        </div>
                                        <p class="card-text"><i class="fas fa-quote-left opacity-25 fs-1"></i> The most
                                            important day of
                                            a person's education is the first day of school, not graduation day...I
                                            shall always be
                                            thankful to them who helped me to stand in my life.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- Testimonial 2 -->
                            <div class="col-md-4">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title text-center">Tania Arora</h4>
                                        <div class="stars text-center">
                                            ★★★★★
                                        </div>
                                        <p class="card-text"><i class="fas fa-quote-left opacity-25 fs-1"></i> This
                                            school has been such
                                            a true blessing to us. From the infrastructure to the teachers, it’s hands
                                            down the best
                                            school around. Thank you to JCS.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- Testimonial 3 -->
                            <div class="col-md-4">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title text-center">Navdeep Dhunna</h4>
                                        <div class="stars text-center">
                                            ★★★★★
                                        </div>
                                        <p class="card-text"><i class="fas fa-quote-left opacity-25 fs-1"></i> I have
                                            had an amazing
                                            experience with JCS. I cannot forget the days I spent there with teachers
                                            and friends. The
                                            quality of education at JCS is wonderful.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- Additional Testimonials -->
                            <div class="col-md-4 mt-3">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title text-center">Veer K</h4>
                                        <div class="stars text-center">
                                            ★★★★★
                                        </div>
                                        <p class="card-text"> <i class="fas fa-quote-left opacity-25 fs-1"></i> The
                                            staff,
                                            infrastructure, facilities, and environment are unmatched. Once you become a
                                            JCSian, you are
                                            always part of it.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mt-3">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title text-center">Sukhman Chandi</h4>
                                        <div class="stars text-center">
                                            ★★★★★
                                        </div>
                                        <p class="card-text"> <i class="fas fa-quote-left opacity-25 fs-1"></i> Awesome
                                            school with
                                            extraordinary staff that helps young ones explore their talent in front of
                                            the world!</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mt-3">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title text-center">Neha Chatrath</h4>
                                        <div class="stars text-center">
                                            ★★★★★
                                        </div>
                                        <p class="card-text"> <i class="fas fa-quote-left opacity-25 fs-1"></i> It is an
                                            educational
                                            place where I am working to cherish my knowledge and enhance my skills in a
                                            healthy
                                            environment.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>
                <section class="py-5 section-container">
                    <div class="container">
                        <div class="row">
                            <!-- Image Section -->
                            <div class="col-md-6">
                                <img src="img/noooo.jpg" class="img-fluid rounded img-thumbnail" alt="Admission Image">
                            </div>
                            <!-- Admission Enquiry Form -->
                            <div class="col-md-6">
                                <h2 class="text-center mb-4">Admission Enquiry Form</h2>
                                <form>
                                    <div class="mb-3">
                                        <label for="studentName" class="form-label">Student Name</label>
                                        <input type="text" class="form-control" id="studentName"
                                            placeholder="Enter student's name">
                                    </div>


                                    <div class="mb-3">
                                        <label for="phone" class="form-label">Phone</label>
                                        <input type="tel" class="form-control" id="phone"
                                            placeholder="Enter your phone number">
                                    </div>

                                    <div class="mb-3">
                                        <label for="message" class="form-label">Message</label>
                                        <textarea class="form-control" id="message" rows="4"
                                            placeholder="Enter your message"></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-primary w-100">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

        </div>
    </div>

    <?php include 'footer_links.php';
    include 'footer.php'; ?>
    ?>
</body>

</html>