<footer>
    <p class="text-center bg-light">&copy; <?= date('Y') ?> All Rights Resvered By Jogindra Convent School</p>
</footer>