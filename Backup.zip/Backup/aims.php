<?php 
include 'includes/db.php';
$query = "SELECT * FROM students WHERE designation = 'STUDENT OF THE YEAR' ORDER BY id ASC LIMIT 10";
$result = mysqli_query($conn, $query);
$dir = "uploads/";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jogindra Convent School</title>
    <?php include 'top_links.php'; ?>
</head>

<body>

<div class="container my-3">
    <div class="row">
        
        <!-- Sidebar -->
        <div class="col-md-2">
            <?php include 'sidebar.php'; ?>
        </div>

        <!-- Main Content Area -->
        <div class="col-md-10">

            <!-- Heading -->
            <h2 class="mb-4 fw-bold text-primary border-bottom pb-2">Aims</h2>

            <!-- Main Section -->
            <section class="py-4 section-container">
                <div class="container">

                    <div class="row">
                        <div class="col-md-4">
                            <img src="img/rightimg.jpg" class="img-fluid img-thumbnail w-100 shadow-lg" alt="School Building">
                        </div>
                        <div class="col-md-8">
                            <ul class="daljit text-break text-justify bg-light p-3 rounded shadow-sm">
                                <li><i class="fa fa-arrow-right" aria-hidden="true"></i> To impart value based quality education. </li>
                                <li><i class="fa fa-arrow-right" aria-hidden="true"></i> To achieve and sustain academic standards, qualitatively as well as quantitatively. </li>
                                <li><i class="fa fa-arrow-right" aria-hidden="true"></i> To enable the students to learn self discipline. To provide facilities for physical and spiritual development. </li>
                                <li><i class="fa fa-arrow-right" aria-hidden="true"></i> To raise the moral of the students in sense of politeness, respect and manners. </li>
                                <li><i class="fa fa-arrow-right" aria-hidden="true"></i> To instill among them a national feeling and love for their ancient cultural and national heritage. </li>
                                <li><i class="fa fa-arrow-right" aria-hidden="true"></i> To sharpen their aesthetic sense and humor for appreciation of art and higher value of life. </li>
                                <li><i class="fa fa-arrow-right" aria-hidden="true"></i> To have a wide vision and clear thinking to face the challenge of life. </li>
                                <li><i class="fa fa-arrow-right" aria-hidden="true"></i> To make them respected and responsible citizens of future India. </li>
                            </ul> 
                        </div>
                    </div>

                </div>
            </section>

        </div>
    </div>
</div>

</body>
</html>
